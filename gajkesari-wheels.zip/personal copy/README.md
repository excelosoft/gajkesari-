# Gajkesari Wheels - Car Service Website

A comprehensive car service company website with a React frontend and Java Spring Boot backend.

## Project Overview

Gajkesari Wheels is a car service company website that offers various car services including express 90-minute service, periodic maintenance, AC service, car spa & cleaning, denting & painting, and more. The website allows customers to book services, track their service status, and manage their profiles.

## Features

- **90-Minute Express Service**: The flagship service with a guarantee of completion within 90 minutes
- **Real-Time Service Tracking**: Customers can track the progress of their service
- **Doorstep Service**: Option for pickup and delivery
- **Transparent Pricing**: Clear pricing with no hidden fees
- **Quality Guarantee**: Service quality assurance
- **Digital Documentation**: Complete service history with photos and videos
- **WhatsApp Integration**: Direct customer communication channel
- **Online Booking System**: Quick and easy service scheduling

## Tech Stack

### Frontend
- React.js
- Redux for state management
- React Router for navigation
- Styled Components / CSS
- Axios for API communication

### Backend
- Java Spring Boot
- Spring Security with JWT
- Spring Data JPA
- PostgreSQL database
- RESTful API architecture

## Project Structure

```
personal/
├── frontend/             # React frontend
│   ├── public/           # Public assets
│   └── src/              # Source code
│       ├── assets/       # Images, icons, etc.
│       ├── components/   # Reusable components
│       ├── pages/        # Page components
│       ├── app/          # Redux store
│       └── features/     # Redux slices
└── backend/              # Spring Boot backend
    ├── src/              # Source code
    │   ├── main/
    │   │   ├── java/     # Java code
    │   │   └── resources/ # Configuration files
    └── pom.xml           # Maven dependencies
```

## Getting Started

### Prerequisites
- Node.js and npm
- Java 17 or higher
- Maven
- PostgreSQL

### Running the Frontend
```bash
cd frontend
npm install
npm start
```

### Running the Backend
```bash
cd backend
mvn spring-boot:run
```

## API Endpoints

### Authentication
- POST /api/auth/signin - Sign in
- POST /api/auth/signup - Register

### Services
- GET /api/services - Get all services
- GET /api/services/{id} - Get service by ID
- GET /api/services/category/{category} - Get services by category

### Bookings
- GET /api/bookings - Get all bookings (admin/manager)
- GET /api/bookings/{id} - Get booking by ID
- GET /api/bookings/my-bookings - Get user's bookings
- POST /api/bookings - Create a booking
- PUT /api/bookings/{id}/status - Update booking status
- PUT /api/bookings/{id}/assign - Assign technician to booking

## License
This project is licensed under the MIT License.
