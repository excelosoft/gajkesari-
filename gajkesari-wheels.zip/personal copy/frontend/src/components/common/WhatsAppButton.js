import React from 'react';
import './WhatsAppButton.css';

const WhatsAppButton = () => {
  const phoneNumber = '+919844828528'; // Replace with your actual WhatsApp number
  const message = 'Hello! I would like to know more about your car services.';
  
  const handleWhatsAppClick = () => {
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <button className="whatsapp-button" onClick={handleWhatsAppClick} aria-label="Contact us on WhatsApp">
      <i className="fab fa-whatsapp"></i>
    </button>
  );
};

export default WhatsAppButton;
