import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';
import logo from '../../assets/images/logo.svg';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-logo">
            <img src={logo} alt="Gajkesari Wheels" />
            <p>
              Looking for a reliable car mechanic near you? Gajkesari Wheels is your trusted car repair partner, bringing professional auto mechanics right to your doorstep. We offer comprehensive car repair and maintenance services across major cities in India, making quality car care accessible and convenient.
            </p>
          </div>

          <div className="footer-links">
            <div className="footer-section">
              <h3>Quick Links</h3>
              <ul>
                <li><Link to="/">Home</Link></li>
                <li><Link to="/services">Services</Link></li>
                <li><Link to="/contact">Contact</Link></li>
                <li><Link to="/about">About</Link></li>
                <li><Link to="/blog">Blog</Link></li>
                <li><Link to="/partner-with-us">Partner With Us</Link></li>
              </ul>
            </div>

            <div className="footer-section">
              <h3>Our Services</h3>
              <ul>
                <li><Link to="/services/periodic-maintenance">Periodic Maintenance</Link></li>
                <li><Link to="/services/car-ac-service">Car AC Service</Link></li>
                <li><Link to="/services/denting-painting">Denting & Painting</Link></li>
                <li><Link to="/services/car-detailing">Car Detailing</Link></li>
                <li><Link to="/services/wheel-care">Wheel Care</Link></li>
                <li><Link to="/services/car-inspection">Car Inspection</Link></li>
              </ul>
            </div>

            <div className="footer-section">
              <h3>Legal</h3>
              <ul>
                <li><Link to="/privacy-policy">Privacy Policy</Link></li>
                <li><Link to="/terms-conditions">Terms & Conditions</Link></li>
                <li><Link to="/refund-policy">Refund Policy</Link></li>
              </ul>
            </div>
          </div>

          <div className="footer-contact">
            <h3>Connect With Us</h3>
            <div className="social-icons">
              <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="https://youtube.com" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-youtube"></i>
              </a>
              <a href="mailto:contact@gajkesariwheels.com">
                <i className="fas fa-envelope"></i>
              </a>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <p>
            Find the best car mechanic near me, auto repair shop near me, car service center near me, and car AC service near me. GajkesariWheels provides professional automotive mechanics and car repair services across India.
          </p>
          <p className="copyright">
            &copy; {currentYear} GajkesariWheels. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
