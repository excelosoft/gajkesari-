import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import './ServiceDetailPage.css';

// Import service icons (these would be actual images in a real implementation)
import expressServiceIcon from '../assets/images/services/express-service.svg';

const ServiceDetailPage = () => {
  const { id } = useParams();
  const [service, setService] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // In a real implementation, this would fetch data from the backend API
    // For now, we'll use mock data
    const mockServices = {
      "1": {
        id: 1,
        name: "Express 90-Minute Service",
        description: "Get your car serviced in just 90 minutes with our express service.",
        longDescription: "Our Express 90-Minute Service is designed for busy professionals who need their car serviced quickly without compromising on quality. Our team of expert technicians work simultaneously on your vehicle to complete a comprehensive service in just 90 minutes. If we don't complete it within 90 minutes, the service is free!",
        category: "EXPRESS_SERVICE",
        basePrice: 1999,
        imageUrl: expressServiceIcon,
        durationMinutes: 90,
        inclusions: [
          'Engine oil replacement',
          'Oil filter replacement',
          'Air filter check and cleaning',
          'Cabin filter check',
          'Battery water top-up',
          'Battery terminal cleaning',
          'Coolant top-up',
          'Brake fluid top-up',
          'Wiper fluid top-up',
          'Tire pressure check and adjustment',
          'Exterior wash'
        ],
        benefits: [
          'Save time with our 90-minute service guarantee',
          'Transparent pricing with no hidden charges',
          'Skilled technicians with specialized training',
          'Genuine parts and premium oils used',
          'Digital service report with photos and videos',
          'Doorstep pickup and drop available'
        ],
        process: [
          {
            title: 'Initial Inspection',
            description: 'Quick but thorough inspection to identify service requirements',
            duration: '5 mins'
          },
          {
            title: 'Service Planning',
            description: 'Efficient allocation of tasks to specialized technicians',
            duration: '5 mins'
          },
          {
            title: 'Parallel Processing',
            description: 'Multiple services performed simultaneously by expert teams',
            duration: '70 mins'
          },
          {
            title: 'Quality Check',
            description: 'Comprehensive inspection of all serviced components',
            duration: '10 mins'
          }
        ],
        faqs: [
          {
            question: 'What if my car needs additional repairs?',
            answer: 'If our technicians identify any issues that require additional repairs, they will inform you immediately with a detailed explanation and quote. No additional work will be done without your approval.'
          },
          {
            question: 'Is the 90-minute guarantee applicable for all car models?',
            answer: 'Yes, our 90-minute express service is available for all car models. However, certain luxury or specialized vehicles might require additional time for specific components.'
          },
          {
            question: 'Do you use genuine parts?',
            answer: 'Yes, we use only genuine or OEM-approved parts for all our services to ensure quality and reliability.'
          },
          {
            question: 'Can I wait while my car is being serviced?',
            answer: 'Absolutely! We have a comfortable waiting area with complimentary Wi-Fi, refreshments, and a work-friendly environment.'
          }
        ]
      },
      // Additional services would be defined here in a real implementation
    };

    setTimeout(() => {
      if (mockServices[id]) {
        setService(mockServices[id]);
        setLoading(false);
      } else {
        setError('Service not found');
        setLoading(false);
      }
    }, 500); // Simulate API delay
  }, [id]);

  if (loading) {
    return (
      <div className="service-detail-page">
        <div className="container">
          <div className="loading">Loading service details...</div>
        </div>
      </div>
    );
  }

  if (error || !service) {
    return (
      <div className="service-detail-page">
        <div className="container">
          <div className="error">
            {error || 'Service not found'}
            <div className="mt-4">
              <Link to="/services" className="btn btn-primary">
                Back to Services
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="service-detail-page">
      <div className="container">
        <div className="service-header">
          <div className="service-info">
            <h1>{service.name}</h1>
            <p className="service-description">{service.longDescription}</p>
            <div className="service-meta">
              <div className="meta-item">
                <i className="fas fa-clock"></i>
                <span>{service.durationMinutes} minutes</span>
              </div>
              <div className="meta-item">
                <i className="fas fa-rupee-sign"></i>
                <span>Starting at ₹{service.basePrice}</span>
              </div>
            </div>
            <div className="service-actions">
              <Link to="/booking" className="btn btn-primary">
                Book Now
              </Link>
              <a href="tel:+919844828528" className="btn btn-outline">
                Call for Inquiry
              </a>
            </div>
          </div>
          <div className="service-image">
            <img src={service.imageUrl} alt={service.name} />
          </div>
        </div>

        <div className="service-content">
          <div className="service-inclusions">
            <h2>What's Included</h2>
            <ul className="inclusion-list">
              {service.inclusions.map((inclusion, index) => (
                <li key={index}>
                  <i className="fas fa-check-circle"></i>
                  <span>{inclusion}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="service-benefits">
            <h2>Benefits</h2>
            <div className="benefits-grid">
              {service.benefits.map((benefit, index) => (
                <div className="benefit-item" key={index}>
                  <div className="benefit-icon">
                    <i className="fas fa-star"></i>
                  </div>
                  <p>{benefit}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="service-process">
            <h2>Our Process</h2>
            <div className="process-timeline">
              {service.process.map((step, index) => (
                <div className="timeline-step" key={index}>
                  <div className="timeline-icon">
                    <span>{index + 1}</span>
                  </div>
                  <div className="timeline-content">
                    <h3>{step.title}</h3>
                    <p className="time">{step.duration}</p>
                    <p>{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="service-faqs">
            <h2>Frequently Asked Questions</h2>
            <div className="faq-list">
              {service.faqs.map((faq, index) => (
                <div className="faq-item" key={index}>
                  <div className="faq-question">
                    <i className="fas fa-question-circle"></i>
                    <h3>{faq.question}</h3>
                  </div>
                  <div className="faq-answer">
                    <p>{faq.answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="related-services">
          <h2>You May Also Be Interested In</h2>
          <div className="related-services-grid">
            <div className="related-service-card">
              <div className="related-service-icon">
                <i className="fas fa-calendar-check"></i>
              </div>
              <h3>Periodic Service</h3>
              <p>Regular maintenance and servicing for your vehicle.</p>
              <Link to="/services/2" className="btn btn-outline">
                View Details
              </Link>
            </div>
            <div className="related-service-card">
              <div className="related-service-icon">
                <i className="fas fa-snowflake"></i>
              </div>
              <h3>AC Service</h3>
              <p>Professional car AC repair and maintenance.</p>
              <Link to="/services/3" className="btn btn-outline">
                View Details
              </Link>
            </div>
            <div className="related-service-card">
              <div className="related-service-icon">
                <i className="fas fa-shower"></i>
              </div>
              <h3>Car Spa & Cleaning</h3>
              <p>Professional car cleaning services.</p>
              <Link to="/services/4" className="btn btn-outline">
                View Details
              </Link>
            </div>
          </div>
        </div>

        <div className="service-cta">
          <h2>Ready to Experience Our {service.name}?</h2>
          <p>Book now and get your car serviced by our expert technicians.</p>
          <div className="cta-buttons">
            <Link to="/booking" className="btn btn-primary btn-lg">
              Book Now
            </Link>
            <a href="https://wa.me/919844828528" className="btn btn-outline btn-lg">
              <i className="fab fa-whatsapp"></i> Chat on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceDetailPage;
