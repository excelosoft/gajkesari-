import React, { useState } from 'react';
import './FranchisePage.css';

const FranchisePage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    city: '',
    investment: '',
    experience: '',
    message: ''
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  const validateForm = () => {
    const newErrors = {};
    
    // Name validation
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    // Email validation
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    // Phone validation
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(formData.phone.replace(/[^0-9]/g, ''))) {
      newErrors.phone = 'Phone number must be 10 digits';
    }
    
    // City validation
    if (!formData.city.trim()) {
      newErrors.city = 'City is required';
    }
    
    // Investment validation
    if (!formData.investment) {
      newErrors.investment = 'Investment range is required';
    }
    
    // Experience validation
    if (!formData.experience) {
      newErrors.experience = 'Experience is required';
    }
    
    return newErrors;
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validateForm();
    
    if (Object.keys(newErrors).length === 0) {
      setIsSubmitting(true);
      
      // Simulate API call
      setTimeout(() => {
        console.log('Franchise application submitted:', formData);
        setIsSubmitting(false);
        setSubmitSuccess(true);
        
        // Reset form after successful submission
        setFormData({
          name: '',
          email: '',
          phone: '',
          city: '',
          investment: '',
          experience: '',
          message: ''
        });
        
        // Reset success message after 5 seconds
        setTimeout(() => {
          setSubmitSuccess(false);
        }, 5000);
      }, 1500);
    } else {
      setErrors(newErrors);
    }
  };
  
  return (
    <div className="franchise-page">
      <div className="container">
        <div className="franchise-header">
          <h1>Franchise Opportunities</h1>
          <p>Join the GajkesariWheels family and be part of India's fastest-growing car service network</p>
        </div>
        
        <div className="franchise-content">
          <div className="franchise-intro">
            <div className="intro-content">
              <h2>Why Partner With GajkesariWheels?</h2>
              <p>
                GajkesariWheels is revolutionizing the car service industry in India with our innovative 90-minute express service model. As we expand across the country, we're looking for passionate entrepreneurs to join our franchise network.
              </p>
              <p>
                Our franchise model offers a proven business system, comprehensive training, marketing support, and a strong brand presence to help you succeed in the automotive service industry.
              </p>
              
              <div className="stats-row">
                <div className="stat-card">
                  <div className="stat-number">50+</div>
                  <div className="stat-label">Franchise Locations</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">₹25L+</div>
                  <div className="stat-label">Average Annual Revenue</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">18-24</div>
                  <div className="stat-label">Months to Break Even</div>
                </div>
              </div>
            </div>
            
            <div className="intro-image">
              {/* This would be an actual image in a real implementation */}
              <div className="image-placeholder">
                <span>Franchise Image</span>
              </div>
            </div>
          </div>
          
          <div className="benefits-section">
            <h2>Franchise Benefits</h2>
            
            <div className="benefits-grid">
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-trademark"></i>
                </div>
                <h3>Established Brand</h3>
                <p>Leverage our recognized brand name and reputation for quality service</p>
              </div>
              
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-tools"></i>
                </div>
                <h3>Technical Support</h3>
                <p>Ongoing technical training and support for your service team</p>
              </div>
              
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-graduation-cap"></i>
                </div>
                <h3>Comprehensive Training</h3>
                <p>Thorough training program covering operations, management, and marketing</p>
              </div>
              
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-bullhorn"></i>
                </div>
                <h3>Marketing Assistance</h3>
                <p>National and local marketing support to drive customer acquisition</p>
              </div>
              
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-cogs"></i>
                </div>
                <h3>Operational Systems</h3>
                <p>Proven operational systems and processes to ensure efficiency</p>
              </div>
              
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-chart-line"></i>
                </div>
                <h3>Growth Potential</h3>
                <p>Opportunity to grow with a rapidly expanding brand in a lucrative industry</p>
              </div>
            </div>
          </div>
          
          <div className="investment-section">
            <h2>Investment Overview</h2>
            
            <div className="investment-details">
              <div className="investment-card">
                <h3>Initial Investment</h3>
                <p className="investment-range">₹30-50 Lakhs</p>
                <p className="investment-note">Varies based on location and size of facility</p>
                
                <h4>What's Included:</h4>
                <ul>
                  <li>Franchise Fee</li>
                  <li>Equipment and Tools</li>
                  <li>Initial Inventory</li>
                  <li>Training</li>
                  <li>Marketing Launch Package</li>
                </ul>
              </div>
              
              <div className="investment-card">
                <h3>Ongoing Fees</h3>
                <div className="fee-item">
                  <span className="fee-label">Royalty Fee:</span>
                  <span className="fee-value">7% of Gross Sales</span>
                </div>
                <div className="fee-item">
                  <span className="fee-label">Marketing Fee:</span>
                  <span className="fee-value">2% of Gross Sales</span>
                </div>
                
                <h4>Space Requirements:</h4>
                <p>2,000-3,000 sq. ft. with parking space</p>
                
                <h4>Ideal Locations:</h4>
                <p>High-traffic areas, commercial zones, automotive hubs</p>
              </div>
            </div>
          </div>
          
          <div className="process-section">
            <h2>Franchise Process</h2>
            
            <div className="process-steps">
              <div className="process-step">
                <div className="step-number">1</div>
                <div className="step-content">
                  <h3>Initial Inquiry</h3>
                  <p>Submit your application through our franchise inquiry form</p>
                </div>
              </div>
              
              <div className="process-step">
                <div className="step-number">2</div>
                <div className="step-content">
                  <h3>Preliminary Discussion</h3>
                  <p>Initial call to discuss your background and our franchise opportunity</p>
                </div>
              </div>
              
              <div className="process-step">
                <div className="step-number">3</div>
                <div className="step-content">
                  <h3>Franchise Disclosure</h3>
                  <p>Review of franchise disclosure document and financial requirements</p>
                </div>
              </div>
              
              <div className="process-step">
                <div className="step-number">4</div>
                <div className="step-content">
                  <h3>Discovery Day</h3>
                  <p>Visit our headquarters and meet the leadership team</p>
                </div>
              </div>
              
              <div className="process-step">
                <div className="step-number">5</div>
                <div className="step-content">
                  <h3>Agreement & Training</h3>
                  <p>Sign franchise agreement and begin comprehensive training</p>
                </div>
              </div>
              
              <div className="process-step">
                <div className="step-number">6</div>
                <div className="step-content">
                  <h3>Grand Opening</h3>
                  <p>Launch your GajkesariWheels franchise with our support team</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="testimonials-section">
            <h2>Franchise Success Stories</h2>
            
            <div className="testimonial-card">
              <div className="testimonial-content">
                <p>
                  "Joining the GajkesariWheels franchise network was the best business decision I've made. The training and support have been exceptional, and our service center has exceeded our revenue projections in the first year."
                </p>
              </div>
              <div className="testimonial-author">
                <div className="author-initial">R</div>
                <div className="author-details">
                  <h4>Rajesh Sharma</h4>
                  <p>Franchise Owner - Delhi NCR</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="application-section">
            <h2>Franchise Application</h2>
            
            {submitSuccess ? (
              <div className="success-message">
                <i className="fas fa-check-circle"></i>
                <p>Thank you for your interest in GajkesariWheels franchise! Our franchise development team will contact you within 2-3 business days to discuss the next steps.</p>
              </div>
            ) : (
              <form className="franchise-form" onSubmit={handleSubmit}>
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="name">Full Name</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className={errors.name ? 'error' : ''}
                    />
                    {errors.name && <span className="error-message">{errors.name}</span>}
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="email">Email Address</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={errors.email ? 'error' : ''}
                    />
                    {errors.email && <span className="error-message">{errors.email}</span>}
                  </div>
                </div>
                
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="phone">Phone Number</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className={errors.phone ? 'error' : ''}
                    />
                    {errors.phone && <span className="error-message">{errors.phone}</span>}
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="city">City of Interest</label>
                    <input
                      type="text"
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleChange}
                      className={errors.city ? 'error' : ''}
                    />
                    {errors.city && <span className="error-message">{errors.city}</span>}
                  </div>
                </div>
                
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="investment">Available Investment</label>
                    <select
                      id="investment"
                      name="investment"
                      value={formData.investment}
                      onChange={handleChange}
                      className={errors.investment ? 'error' : ''}
                    >
                      <option value="">Select Investment Range</option>
                      <option value="20-30L">₹20-30 Lakhs</option>
                      <option value="30-40L">₹30-40 Lakhs</option>
                      <option value="40-50L">₹40-50 Lakhs</option>
                      <option value="50L+">₹50+ Lakhs</option>
                    </select>
                    {errors.investment && <span className="error-message">{errors.investment}</span>}
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="experience">Business Experience</label>
                    <select
                      id="experience"
                      name="experience"
                      value={formData.experience}
                      onChange={handleChange}
                      className={errors.experience ? 'error' : ''}
                    >
                      <option value="">Select Experience</option>
                      <option value="No Experience">No Prior Business Experience</option>
                      <option value="Some Experience">Some Business Experience</option>
                      <option value="Automotive Experience">Experience in Automotive Industry</option>
                      <option value="Franchise Experience">Previous Franchise Experience</option>
                    </select>
                    {errors.experience && <span className="error-message">{errors.experience}</span>}
                  </div>
                </div>
                
                <div className="form-group">
                  <label htmlFor="message">Additional Information</label>
                  <textarea
                    id="message"
                    name="message"
                    rows="4"
                    value={formData.message}
                    onChange={handleChange}
                  ></textarea>
                </div>
                
                <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
                  {isSubmitting ? 'Submitting...' : 'Submit Application'}
                </button>
              </form>
            )}
          </div>
          
          <div className="faq-section">
            <h2>Frequently Asked Questions</h2>
            
            <div className="faq-grid">
              <div className="faq-item">
                <h3>What is the typical ROI timeline?</h3>
                <p>Most franchisees achieve return on investment within 18-24 months, depending on location, local market conditions, and operational efficiency.</p>
              </div>
              
              <div className="faq-item">
                <h3>Do I need automotive experience?</h3>
                <p>While automotive experience is beneficial, it's not required. Our comprehensive training program will equip you with the necessary knowledge and skills.</p>
              </div>
              
              <div className="faq-item">
                <h3>What territories are available?</h3>
                <p>We currently have franchise opportunities available in major cities across India. Contact our franchise development team for specific territory availability.</p>
              </div>
              
              <div className="faq-item">
                <h3>What ongoing support do you provide?</h3>
                <p>We provide continuous operational support, marketing assistance, technical training, business coaching, and access to our proprietary management systems.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FranchisePage;
