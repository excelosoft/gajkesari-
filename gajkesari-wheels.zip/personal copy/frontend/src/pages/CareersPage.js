import React, { useState } from 'react';
import './CareersPage.css';

const CareersPage = () => {
  // Mock job listings
  const [jobListings, setJobListings] = useState([
    {
      id: 1,
      title: 'Senior Automobile Technician',
      location: 'Jaipur, Rajasthan',
      type: 'Full-time',
      experience: '3-5 years',
      description: 'We are looking for an experienced automobile technician with expertise in diagnosing and repairing various car models. The ideal candidate should have strong knowledge of car engines, electrical systems, and modern diagnostic equipment.',
      responsibilities: [
        'Diagnose and repair mechanical and electrical issues in various car models',
        'Perform routine maintenance services like oil changes, brake inspections, etc.',
        'Use diagnostic equipment to identify problems and recommend solutions',
        'Maintain detailed service records for all work performed',
        'Ensure all repairs meet quality and safety standards'
      ],
      requirements: [
        'Diploma or certification in Automobile Engineering or related field',
        '3-5 years of experience as an automobile technician',
        'Strong knowledge of car engines, electrical systems, and diagnostic tools',
        'Ability to work in a fast-paced environment',
        'Excellent problem-solving skills'
      ]
    },
    {
      id: 2,
      title: 'Customer Service Representative',
      location: 'Delhi NCR',
      type: 'Full-time',
      experience: '1-3 years',
      description: 'We are seeking a customer service representative to handle customer inquiries, process bookings, and ensure customer satisfaction. The ideal candidate should have excellent communication skills and a customer-first attitude.',
      responsibilities: [
        'Handle customer inquiries via phone, email, and in-person',
        'Process service bookings and manage scheduling',
        'Explain service details and pricing to customers',
        'Address customer complaints and escalate issues when necessary',
        'Maintain customer records and follow up on service feedback'
      ],
      requirements: [
        'Bachelor\'s degree in any discipline',
        '1-3 years of experience in customer service',
        'Excellent communication and interpersonal skills',
        'Proficiency in MS Office and CRM software',
        'Ability to work in shifts'
      ]
    },
    {
      id: 3,
      title: 'Operations Manager',
      location: 'Mumbai, Maharashtra',
      type: 'Full-time',
      experience: '5-8 years',
      description: 'We are looking for an experienced Operations Manager to oversee our service center operations. The ideal candidate will have a strong background in automotive service management and team leadership.',
      responsibilities: [
        'Oversee daily operations of the service center',
        'Manage a team of technicians and service advisors',
        'Ensure service quality and customer satisfaction',
        'Optimize workflow and resource allocation',
        'Implement and maintain operational policies and procedures'
      ],
      requirements: [
        'Bachelor\'s degree in Business Administration, Automotive Management, or related field',
        '5-8 years of experience in automotive service operations',
        'Strong leadership and team management skills',
        'Excellent problem-solving and decision-making abilities',
        'Knowledge of automotive industry standards and best practices'
      ]
    },
    {
      id: 4,
      title: 'Marketing Specialist',
      location: 'Bangalore, Karnataka',
      type: 'Full-time',
      experience: '2-4 years',
      description: 'We are seeking a Marketing Specialist to develop and implement marketing strategies for our automotive service business. The ideal candidate will have experience in digital marketing and content creation.',
      responsibilities: [
        'Develop and implement marketing campaigns across various channels',
        'Create engaging content for social media, website, and email marketing',
        'Analyze marketing metrics and prepare reports',
        'Collaborate with the design team for marketing materials',
        'Stay updated on industry trends and competitor activities'
      ],
      requirements: [
        'Bachelor\'s degree in Marketing, Communications, or related field',
        '2-4 years of experience in marketing, preferably in the automotive industry',
        'Proficiency in digital marketing tools and social media platforms',
        'Strong analytical and creative skills',
        'Excellent written and verbal communication abilities'
      ]
    }
  ]);

  const [selectedJob, setSelectedJob] = useState(null);
  const [applicationForm, setApplicationForm] = useState({
    name: '',
    email: '',
    phone: '',
    resume: null,
    coverLetter: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleJobSelect = (jobId) => {
    const job = jobListings.find(job => job.id === jobId);
    setSelectedJob(job);
    // Reset form and status when selecting a new job
    setApplicationForm({
      name: '',
      email: '',
      phone: '',
      resume: null,
      coverLetter: ''
    });
    setErrors({});
    setSubmitSuccess(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setApplicationForm({
      ...applicationForm,
      [name]: value
    });
  };

  const handleFileChange = (e) => {
    setApplicationForm({
      ...applicationForm,
      resume: e.target.files[0]
    });
  };

  const validateForm = () => {
    const newErrors = {};
    
    // Name validation
    if (!applicationForm.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    // Email validation
    if (!applicationForm.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(applicationForm.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    // Phone validation
    if (!applicationForm.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\d{10}$/.test(applicationForm.phone.replace(/[^0-9]/g, ''))) {
      newErrors.phone = 'Phone number must be 10 digits';
    }
    
    // Resume validation
    if (!applicationForm.resume) {
      newErrors.resume = 'Resume is required';
    }
    
    // Cover letter validation
    if (!applicationForm.coverLetter.trim()) {
      newErrors.coverLetter = 'Cover letter is required';
    }
    
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validateForm();
    
    if (Object.keys(newErrors).length === 0) {
      setIsSubmitting(true);
      
      // Simulate API call
      setTimeout(() => {
        console.log('Application submitted:', applicationForm);
        setIsSubmitting(false);
        setSubmitSuccess(true);
      }, 1500);
    } else {
      setErrors(newErrors);
    }
  };

  return (
    <div className="careers-page">
      <div className="container">
        <div className="careers-header">
          <h1>Join Our Team</h1>
          <p>Build your career with GajkesariWheels and be part of revolutionizing car care in India</p>
        </div>
        
        <div className="careers-content">
          <div className="why-join-section">
            <h2>Why Join GajkesariWheels?</h2>
            <div className="benefits-grid">
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-chart-line"></i>
                </div>
                <h3>Growth Opportunities</h3>
                <p>We're growing rapidly, creating numerous opportunities for career advancement and professional development.</p>
              </div>
              
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-lightbulb"></i>
                </div>
                <h3>Innovation Culture</h3>
                <p>We encourage creative thinking and innovative solutions to transform the automotive service industry.</p>
              </div>
              
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-users"></i>
                </div>
                <h3>Collaborative Environment</h3>
                <p>Work with a diverse team of professionals who are passionate about delivering exceptional service.</p>
              </div>
              
              <div className="benefit-card">
                <div className="benefit-icon">
                  <i className="fas fa-graduation-cap"></i>
                </div>
                <h3>Learning & Development</h3>
                <p>Access to training programs, workshops, and certifications to enhance your skills and knowledge.</p>
              </div>
            </div>
          </div>
          
          <div className="job-listings-section">
            <h2>Current Openings</h2>
            
            <div className="job-listings">
              {jobListings.map(job => (
                <div 
                  key={job.id} 
                  className={`job-card ${selectedJob && selectedJob.id === job.id ? 'selected' : ''}`}
                  onClick={() => handleJobSelect(job.id)}
                >
                  <h3>{job.title}</h3>
                  <div className="job-details">
                    <span><i className="fas fa-map-marker-alt"></i> {job.location}</span>
                    <span><i className="fas fa-briefcase"></i> {job.type}</span>
                    <span><i className="fas fa-user-clock"></i> {job.experience}</span>
                  </div>
                  <p className="job-description">{job.description}</p>
                  <button className="btn btn-outline">View Details</button>
                </div>
              ))}
            </div>
          </div>
          
          {selectedJob && (
            <div className="job-detail-section">
              <h2>{selectedJob.title}</h2>
              <div className="job-meta">
                <span><i className="fas fa-map-marker-alt"></i> {selectedJob.location}</span>
                <span><i className="fas fa-briefcase"></i> {selectedJob.type}</span>
                <span><i className="fas fa-user-clock"></i> {selectedJob.experience}</span>
              </div>
              
              <div className="job-description">
                <p>{selectedJob.description}</p>
                
                <h3>Responsibilities</h3>
                <ul>
                  {selectedJob.responsibilities.map((responsibility, index) => (
                    <li key={index}>{responsibility}</li>
                  ))}
                </ul>
                
                <h3>Requirements</h3>
                <ul>
                  {selectedJob.requirements.map((requirement, index) => (
                    <li key={index}>{requirement}</li>
                  ))}
                </ul>
              </div>
              
              <div className="application-form-container">
                <h3>Apply for this Position</h3>
                
                {submitSuccess ? (
                  <div className="success-message">
                    <i className="fas fa-check-circle"></i>
                    <p>Your application has been submitted successfully! We'll review your application and get back to you soon.</p>
                  </div>
                ) : (
                  <form className="application-form" onSubmit={handleSubmit}>
                    <div className="form-row">
                      <div className="form-group">
                        <label htmlFor="name">Full Name</label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={applicationForm.name}
                          onChange={handleInputChange}
                          className={errors.name ? 'error' : ''}
                        />
                        {errors.name && <span className="error-message">{errors.name}</span>}
                      </div>
                      
                      <div className="form-group">
                        <label htmlFor="email">Email Address</label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={applicationForm.email}
                          onChange={handleInputChange}
                          className={errors.email ? 'error' : ''}
                        />
                        {errors.email && <span className="error-message">{errors.email}</span>}
                      </div>
                    </div>
                    
                    <div className="form-group">
                      <label htmlFor="phone">Phone Number</label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        value={applicationForm.phone}
                        onChange={handleInputChange}
                        className={errors.phone ? 'error' : ''}
                      />
                      {errors.phone && <span className="error-message">{errors.phone}</span>}
                    </div>
                    
                    <div className="form-group">
                      <label htmlFor="resume">Resume (PDF or DOCX)</label>
                      <input
                        type="file"
                        id="resume"
                        name="resume"
                        accept=".pdf,.docx"
                        onChange={handleFileChange}
                        className={errors.resume ? 'error' : ''}
                      />
                      {errors.resume && <span className="error-message">{errors.resume}</span>}
                    </div>
                    
                    <div className="form-group">
                      <label htmlFor="coverLetter">Cover Letter</label>
                      <textarea
                        id="coverLetter"
                        name="coverLetter"
                        rows="5"
                        value={applicationForm.coverLetter}
                        onChange={handleInputChange}
                        className={errors.coverLetter ? 'error' : ''}
                      ></textarea>
                      {errors.coverLetter && <span className="error-message">{errors.coverLetter}</span>}
                    </div>
                    
                    <button type="submit" className="btn btn-primary" disabled={isSubmitting}>
                      {isSubmitting ? 'Submitting...' : 'Submit Application'}
                    </button>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>
        
        <div className="careers-cta">
          <h2>Don't see a position that matches your skills?</h2>
          <p>We're always looking for talented individuals to join our team. Send your resume to careers@gajkesariwheels.com</p>
        </div>
      </div>
    </div>
  );
};

export default CareersPage;
