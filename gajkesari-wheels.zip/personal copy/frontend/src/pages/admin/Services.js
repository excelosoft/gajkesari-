import React, { useState, useEffect } from 'react';
import './AdminStyles.css';

const Services = () => {
  // Mock data for services
  const [services, setServices] = useState([
    {
      id: 1,
      name: 'Express Service',
      category: 'Maintenance',
      price: '₹2,499',
      description: 'Complete car service in 90 minutes or less. Includes oil change, filter replacement, and basic inspection.',
      isActive: true
    },
    {
      id: 2,
      name: 'Periodic Maintenance',
      category: 'Maintenance',
      price: '₹4,299',
      description: 'Comprehensive maintenance service including oil change, filter replacement, fluid top-up, and detailed inspection.',
      isActive: true
    },
    {
      id: 3,
      name: 'AC Service',
      category: 'AC & Cooling',
      price: '₹3,999',
      description: 'Complete AC system service including gas refill, condenser cleaning, and performance check.',
      isActive: true
    },
    {
      id: 4,
      name: 'Denting & Painting',
      category: 'Body Work',
      price: '₹8,500',
      description: 'Professional dent removal and painting service to restore your car\'s appearance.',
      isActive: true
    },
    {
      id: 5,
      name: 'Battery Replacement',
      category: 'Electrical',
      price: '₹5,200',
      description: 'Battery replacement service with genuine batteries and warranty.',
      isActive: true
    },
    {
      id: 6,
      name: 'Wheel Alignment',
      category: 'Wheels & Tires',
      price: '₹1,200',
      description: 'Precision wheel alignment to ensure optimal tire wear and vehicle handling.',
      isActive: false
    }
  ]);

  // State for new/edit service form
  const [isAddingService, setIsAddingService] = useState(false);
  const [isEditingService, setIsEditingService] = useState(false);
  const [currentService, setCurrentService] = useState({
    id: null,
    name: '',
    category: '',
    price: '',
    description: '',
    isActive: true
  });

  // Categories for dropdown
  const categories = [
    'Maintenance',
    'AC & Cooling',
    'Body Work',
    'Electrical',
    'Wheels & Tires',
    'Engine',
    'Brakes',
    'Detailing'
  ];

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setCurrentService({
      ...currentService,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  // Add new service
  const handleAddService = () => {
    setIsAddingService(true);
    setIsEditingService(false);
    setCurrentService({
      id: services.length + 1,
      name: '',
      category: '',
      price: '',
      description: '',
      isActive: true
    });
  };

  // Edit existing service
  const handleEditService = (service) => {
    setIsEditingService(true);
    setIsAddingService(false);
    setCurrentService({ ...service });
  };

  // Save service (add or update)
  const handleSaveService = (e) => {
    e.preventDefault();
    
    if (isAddingService) {
      setServices([...services, currentService]);
    } else if (isEditingService) {
      setServices(services.map(service => 
        service.id === currentService.id ? currentService : service
      ));
    }
    
    // Reset form
    setIsAddingService(false);
    setIsEditingService(false);
    setCurrentService({
      id: null,
      name: '',
      category: '',
      price: '',
      description: '',
      isActive: true
    });
  };

  // Toggle service active status
  const handleToggleStatus = (id) => {
    setServices(services.map(service => 
      service.id === id ? { ...service, isActive: !service.isActive } : service
    ));
  };

  // Cancel form
  const handleCancelForm = () => {
    setIsAddingService(false);
    setIsEditingService(false);
    setCurrentService({
      id: null,
      name: '',
      category: '',
      price: '',
      description: '',
      isActive: true
    });
  };

  // Simulate data loading
  useEffect(() => {
    // In a real app, this would be an API call
    console.log('Services data loaded');
  }, []);

  return (
    <div className="admin-page">
      <div className="admin-header">
        <h1>Services Management</h1>
        <p>Manage your service offerings</p>
      </div>

      {(isAddingService || isEditingService) ? (
        <div className="dashboard-section">
          <div className="section-header">
            <h2>{isAddingService ? 'Add New Service' : 'Edit Service'}</h2>
          </div>
          
          <form className="admin-form" onSubmit={handleSaveService}>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="name">Service Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={currentService.name}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="category">Category</label>
                <select
                  id="category"
                  name="category"
                  value={currentService.category}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">Select Category</option>
                  {categories.map((category, index) => (
                    <option key={index} value={category}>{category}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="price">Price</label>
                <input
                  type="text"
                  id="price"
                  name="price"
                  value={currentService.price}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="isActive">Status</label>
                <div style={{ marginTop: '10px' }}>
                  <input
                    type="checkbox"
                    id="isActive"
                    name="isActive"
                    checked={currentService.isActive}
                    onChange={handleInputChange}
                    style={{ width: 'auto', marginRight: '10px' }}
                  />
                  <label htmlFor="isActive" style={{ display: 'inline' }}>Active</label>
                </div>
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea
                id="description"
                name="description"
                value={currentService.description}
                onChange={handleInputChange}
                required
              ></textarea>
            </div>
            
            <div className="form-actions">
              <button type="button" className="btn" onClick={handleCancelForm}>Cancel</button>
              <button type="submit" className="btn btn-primary">Save Service</button>
            </div>
          </form>
        </div>
      ) : (
        <>
          <div className="section-header" style={{ marginBottom: '20px' }}>
            <button className="btn btn-primary" onClick={handleAddService}>
              <i className="fas fa-plus"></i> Add New Service
            </button>
          </div>
          
          <div className="services-grid">
            {services.map(service => (
              <div key={service.id} className="service-card">
                <div className="service-header">
                  <div className="service-title">
                    <h3>{service.name}</h3>
                    <div className="service-category">{service.category}</div>
                  </div>
                  <div className="service-price">{service.price}</div>
                </div>
                
                <div className="service-description">{service.description}</div>
                
                <div className="service-footer">
                  <button 
                    className={`btn ${service.isActive ? 'btn-success' : 'btn-danger'}`}
                    onClick={() => handleToggleStatus(service.id)}
                  >
                    {service.isActive ? 'Active' : 'Inactive'}
                  </button>
                  <button className="btn" onClick={() => handleEditService(service)}>Edit</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default Services;
