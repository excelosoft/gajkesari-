import React, { useState, useEffect } from 'react';
import './AdminStyles.css';

const Dashboard = () => {
  // Mock data for dashboard statistics
  const [stats, setStats] = useState({
    totalBookings: 245,
    pendingBookings: 18,
    completedBookings: 227,
    totalRevenue: '₹12,45,780',
    totalCustomers: 189,
    totalServices: 8
  });

  // Mock data for recent bookings
  const [recentBookings, setRecentBookings] = useState([
    {
      id: 'BK00123',
      customer: 'Rahul Sharma',
      service: 'Express Service',
      date: '2025-05-12',
      status: 'Completed',
      amount: '₹2,499'
    },
    {
      id: 'BK00122',
      customer: 'Priya Patel',
      service: 'AC Service',
      date: '2025-05-12',
      status: 'Pending',
      amount: '₹3,999'
    },
    {
      id: 'BK00121',
      customer: 'Amit Singh',
      service: 'Periodic Maintenance',
      date: '2025-05-11',
      status: 'In Progress',
      amount: '₹4,299'
    },
    {
      id: 'BK00120',
      customer: 'Neha Gupta',
      service: 'Denting & Painting',
      date: '2025-05-11',
      status: 'Completed',
      amount: '₹8,500'
    },
    {
      id: 'BK00119',
      customer: 'Rajesh Kumar',
      service: 'Battery Replacement',
      date: '2025-05-10',
      status: 'Completed',
      amount: '₹5,200'
    }
  ]);

  // Mock data for revenue chart
  const [revenueData, setRevenueData] = useState({
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
    data: [125000, 150000, 180000, 220000, 250000]
  });

  // Mock data for service popularity
  const [servicePopularity, setServicePopularity] = useState([
    { name: 'Express Service', count: 98 },
    { name: 'Periodic Maintenance', count: 75 },
    { name: 'AC Service', count: 42 },
    { name: 'Denting & Painting', count: 30 },
    { name: 'Battery Service', count: 25 }
  ]);

  // Simulate data loading
  useEffect(() => {
    // In a real app, this would be an API call
    console.log('Dashboard data loaded');
  }, []);

  return (
    <div className="admin-page">
      <div className="admin-header">
        <h1>Dashboard</h1>
        <p>Welcome to the admin dashboard</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon bookings-icon">
            <i className="fas fa-calendar-check"></i>
          </div>
          <div className="stat-details">
            <h3>Total Bookings</h3>
            <p className="stat-value">{stats.totalBookings}</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon pending-icon">
            <i className="fas fa-clock"></i>
          </div>
          <div className="stat-details">
            <h3>Pending Bookings</h3>
            <p className="stat-value">{stats.pendingBookings}</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon completed-icon">
            <i className="fas fa-check-circle"></i>
          </div>
          <div className="stat-details">
            <h3>Completed Bookings</h3>
            <p className="stat-value">{stats.completedBookings}</p>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon revenue-icon">
            <i className="fas fa-rupee-sign"></i>
          </div>
          <div className="stat-details">
            <h3>Total Revenue</h3>
            <p className="stat-value">{stats.totalRevenue}</p>
          </div>
        </div>
      </div>

      <div className="dashboard-content">
        <div className="dashboard-section">
          <div className="section-header">
            <h2>Recent Bookings</h2>
            <button className="btn btn-sm">View All</button>
          </div>
          
          <div className="table-container">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Booking ID</th>
                  <th>Customer</th>
                  <th>Service</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Amount</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {recentBookings.map(booking => (
                  <tr key={booking.id}>
                    <td>{booking.id}</td>
                    <td>{booking.customer}</td>
                    <td>{booking.service}</td>
                    <td>{booking.date}</td>
                    <td>
                      <span className={`status-badge ${booking.status.toLowerCase().replace(' ', '-')}`}>
                        {booking.status}
                      </span>
                    </td>
                    <td>{booking.amount}</td>
                    <td>
                      <button className="btn btn-sm">View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="dashboard-row">
          <div className="dashboard-section revenue-chart">
            <div className="section-header">
              <h2>Revenue Overview</h2>
              <select className="period-selector">
                <option>Last 5 Months</option>
                <option>Last 12 Months</option>
                <option>This Year</option>
              </select>
            </div>
            
            <div className="chart-container">
              {/* In a real implementation, this would be a chart component */}
              <div className="chart-placeholder">
                <div className="chart-bars">
                  {revenueData.data.map((value, index) => (
                    <div key={index} className="chart-bar" style={{ height: `${(value / 250000) * 100}%` }}>
                      <span className="bar-value">₹{(value / 1000).toFixed(0)}K</span>
                    </div>
                  ))}
                </div>
                <div className="chart-labels">
                  {revenueData.labels.map((label, index) => (
                    <div key={index} className="chart-label">{label}</div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="dashboard-section service-popularity">
            <div className="section-header">
              <h2>Popular Services</h2>
            </div>
            
            <div className="popularity-list">
              {servicePopularity.map((service, index) => (
                <div key={index} className="popularity-item">
                  <div className="service-name">{service.name}</div>
                  <div className="popularity-bar-container">
                    <div 
                      className="popularity-bar" 
                      style={{ width: `${(service.count / servicePopularity[0].count) * 100}%` }}
                    ></div>
                  </div>
                  <div className="service-count">{service.count}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
