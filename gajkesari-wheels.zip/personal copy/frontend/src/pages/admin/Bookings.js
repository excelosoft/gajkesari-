import React, { useState, useEffect } from 'react';
import './AdminStyles.css';

const Bookings = () => {
  // Mock data for bookings
  const [bookings, setBookings] = useState([
    {
      id: 'BK00123',
      customer: {
        name: 'Rahul Sharma',
        phone: '+91 9876543210',
        email: 'rahul.sharma@example.com'
      },
      vehicle: {
        make: 'Maruti Suzuki',
        model: 'Swift',
        year: '2019',
        registrationNumber: 'RJ14 AB 1234'
      },
      service: 'Express Service',
      date: '2025-05-12',
      time: '10:00 AM',
      status: 'Completed',
      amount: '₹2,499',
      technician: 'Amit Kumar',
      notes: 'Customer requested additional windshield washer fluid.'
    },
    {
      id: 'BK00122',
      customer: {
        name: 'Priya Patel',
        phone: '+91 9876543211',
        email: 'priya.patel@example.com'
      },
      vehicle: {
        make: 'Honda',
        model: 'City',
        year: '2020',
        registrationNumber: 'RJ14 CD 5678'
      },
      service: 'AC Service',
      date: '2025-05-12',
      time: '02:00 PM',
      status: 'Pending',
      amount: '₹3,999',
      technician: '',
      notes: ''
    },
    {
      id: 'BK00121',
      customer: {
        name: 'Amit Singh',
        phone: '+91 9876543212',
        email: 'amit.singh@example.com'
      },
      vehicle: {
        make: 'Hyundai',
        model: 'Creta',
        year: '2021',
        registrationNumber: 'RJ14 EF 9012'
      },
      service: 'Periodic Maintenance',
      date: '2025-05-11',
      time: '11:30 AM',
      status: 'In Progress',
      amount: '₹4,299',
      technician: 'Rajesh Verma',
      notes: 'Found additional issue with brake pads. Customer approved replacement.'
    },
    {
      id: 'BK00120',
      customer: {
        name: 'Neha Gupta',
        phone: '+91 9876543213',
        email: 'neha.gupta@example.com'
      },
      vehicle: {
        make: 'Toyota',
        model: 'Innova',
        year: '2018',
        registrationNumber: 'RJ14 GH 3456'
      },
      service: 'Denting & Painting',
      date: '2025-05-11',
      time: '09:00 AM',
      status: 'Completed',
      amount: '₹8,500',
      technician: 'Suresh Yadav',
      notes: ''
    },
    {
      id: 'BK00119',
      customer: {
        name: 'Rajesh Kumar',
        phone: '+91 9876543214',
        email: 'rajesh.kumar@example.com'
      },
      vehicle: {
        make: 'Tata',
        model: 'Nexon',
        year: '2022',
        registrationNumber: 'RJ14 IJ 7890'
      },
      service: 'Battery Replacement',
      date: '2025-05-10',
      time: '03:30 PM',
      status: 'Completed',
      amount: '₹5,200',
      technician: 'Vikram Singh',
      notes: 'Replaced with Exide battery with 3-year warranty.'
    }
  ]);

  // State for booking details view
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [isViewingDetails, setIsViewingDetails] = useState(false);
  
  // State for booking status update
  const [statusOptions] = useState(['Pending', 'Confirmed', 'In Progress', 'Completed', 'Cancelled']);
  const [updatedStatus, setUpdatedStatus] = useState('');
  const [updatedTechnician, setUpdatedTechnician] = useState('');
  const [updatedNotes, setUpdatedNotes] = useState('');

  // Filter states
  const [statusFilter, setStatusFilter] = useState('All');
  const [dateFilter, setDateFilter] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // Technicians list
  const [technicians] = useState([
    'Amit Kumar',
    'Rajesh Verma',
    'Suresh Yadav',
    'Vikram Singh',
    'Deepak Sharma',
    'Manoj Patel'
  ]);

  // View booking details
  const handleViewBooking = (booking) => {
    setSelectedBooking(booking);
    setIsViewingDetails(true);
    setUpdatedStatus(booking.status);
    setUpdatedTechnician(booking.technician);
    setUpdatedNotes(booking.notes);
  };

  // Close booking details
  const handleCloseDetails = () => {
    setIsViewingDetails(false);
    setSelectedBooking(null);
  };

  // Update booking status
  const handleUpdateBooking = () => {
    const updatedBookings = bookings.map(booking => 
      booking.id === selectedBooking.id 
        ? {
            ...booking,
            status: updatedStatus,
            technician: updatedTechnician,
            notes: updatedNotes
          }
        : booking
    );
    
    setBookings(updatedBookings);
    setIsViewingDetails(false);
    setSelectedBooking(null);
  };

  // Filter bookings
  const filteredBookings = bookings.filter(booking => {
    // Status filter
    if (statusFilter !== 'All' && booking.status !== statusFilter) {
      return false;
    }
    
    // Date filter
    if (dateFilter && booking.date !== dateFilter) {
      return false;
    }
    
    // Search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        booking.id.toLowerCase().includes(query) ||
        booking.customer.name.toLowerCase().includes(query) ||
        booking.vehicle.registrationNumber.toLowerCase().includes(query) ||
        booking.service.toLowerCase().includes(query)
      );
    }
    
    return true;
  });

  // Simulate data loading
  useEffect(() => {
    // In a real app, this would be an API call
    console.log('Bookings data loaded');
  }, []);

  return (
    <div className="admin-page">
      <div className="admin-header">
        <h1>Bookings Management</h1>
        <p>Manage service bookings</p>
      </div>

      {isViewingDetails ? (
        <div className="dashboard-section">
          <div className="section-header">
            <h2>Booking Details - {selectedBooking.id}</h2>
            <button className="btn" onClick={handleCloseDetails}>
              <i className="fas fa-times"></i> Close
            </button>
          </div>
          
          <div className="booking-details">
            <div className="details-row">
              <div className="details-column">
                <h3>Customer Information</h3>
                <div className="info-group">
                  <div className="info-label">Name:</div>
                  <div className="info-value">{selectedBooking.customer.name}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Phone:</div>
                  <div className="info-value">{selectedBooking.customer.phone}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Email:</div>
                  <div className="info-value">{selectedBooking.customer.email}</div>
                </div>
              </div>
              
              <div className="details-column">
                <h3>Vehicle Information</h3>
                <div className="info-group">
                  <div className="info-label">Make & Model:</div>
                  <div className="info-value">{selectedBooking.vehicle.make} {selectedBooking.vehicle.model}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Year:</div>
                  <div className="info-value">{selectedBooking.vehicle.year}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Registration:</div>
                  <div className="info-value">{selectedBooking.vehicle.registrationNumber}</div>
                </div>
              </div>
            </div>
            
            <div className="details-row">
              <div className="details-column">
                <h3>Booking Information</h3>
                <div className="info-group">
                  <div className="info-label">Service:</div>
                  <div className="info-value">{selectedBooking.service}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Date & Time:</div>
                  <div className="info-value">{selectedBooking.date} at {selectedBooking.time}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Amount:</div>
                  <div className="info-value">{selectedBooking.amount}</div>
                </div>
              </div>
              
              <div className="details-column">
                <h3>Update Status</h3>
                <div className="form-group">
                  <label>Status</label>
                  <select 
                    value={updatedStatus} 
                    onChange={(e) => setUpdatedStatus(e.target.value)}
                  >
                    {statusOptions.map((status, index) => (
                      <option key={index} value={status}>{status}</option>
                    ))}
                  </select>
                </div>
                
                <div className="form-group">
                  <label>Assigned Technician</label>
                  <select 
                    value={updatedTechnician} 
                    onChange={(e) => setUpdatedTechnician(e.target.value)}
                  >
                    <option value="">Select Technician</option>
                    {technicians.map((tech, index) => (
                      <option key={index} value={tech}>{tech}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            
            <div className="form-group">
              <label>Notes</label>
              <textarea 
                value={updatedNotes} 
                onChange={(e) => setUpdatedNotes(e.target.value)}
                rows="3"
              ></textarea>
            </div>
            
            <div className="form-actions">
              <button className="btn btn-primary" onClick={handleUpdateBooking}>
                Update Booking
              </button>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="filters-section">
            <div className="search-box">
              <input 
                type="text" 
                placeholder="Search bookings..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="filter-controls">
              <div className="filter-group">
                <label>Status:</label>
                <select 
                  value={statusFilter} 
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="All">All Statuses</option>
                  {statusOptions.map((status, index) => (
                    <option key={index} value={status}>{status}</option>
                  ))}
                </select>
              </div>
              
              <div className="filter-group">
                <label>Date:</label>
                <input 
                  type="date" 
                  value={dateFilter}
                  onChange={(e) => setDateFilter(e.target.value)}
                />
              </div>
              
              <button 
                className="btn btn-sm"
                onClick={() => {
                  setStatusFilter('All');
                  setDateFilter('');
                  setSearchQuery('');
                }}
              >
                Clear Filters
              </button>
            </div>
          </div>
          
          <div className="dashboard-section">
            <div className="section-header">
              <h2>Bookings ({filteredBookings.length})</h2>
            </div>
            
            <div className="table-container">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Booking ID</th>
                    <th>Customer</th>
                    <th>Service</th>
                    <th>Vehicle</th>
                    <th>Date & Time</th>
                    <th>Status</th>
                    <th>Amount</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredBookings.map(booking => (
                    <tr key={booking.id}>
                      <td>{booking.id}</td>
                      <td>{booking.customer.name}</td>
                      <td>{booking.service}</td>
                      <td>{booking.vehicle.make} {booking.vehicle.model}</td>
                      <td>{booking.date} {booking.time}</td>
                      <td>
                        <span className={`status-badge ${booking.status.toLowerCase().replace(' ', '-')}`}>
                          {booking.status}
                        </span>
                      </td>
                      <td>{booking.amount}</td>
                      <td>
                        <button 
                          className="btn btn-sm"
                          onClick={() => handleViewBooking(booking)}
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Bookings;
