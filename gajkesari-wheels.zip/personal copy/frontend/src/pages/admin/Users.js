import React, { useState, useEffect } from 'react';
import './AdminStyles.css';

const Users = () => {
  // Mock data for users
  const [users, setUsers] = useState([
    {
      id: 1,
      name: 'Rahul Sharma',
      email: 'rahul.sharma@example.com',
      phone: '+91 9876543210',
      role: 'Customer',
      status: 'Active',
      registeredDate: '2025-01-15'
    },
    {
      id: 2,
      name: 'Priya Patel',
      email: 'priya.patel@example.com',
      phone: '+91 9876543211',
      role: 'Customer',
      status: 'Active',
      registeredDate: '2025-02-20'
    },
    {
      id: 3,
      name: 'Amit Kumar',
      email: 'amit.kumar@example.com',
      phone: '+91 9876543212',
      role: 'Technician',
      status: 'Active',
      registeredDate: '2024-11-10'
    },
    {
      id: 4,
      name: 'Neha Gupta',
      email: 'neha.gupta@example.com',
      phone: '+91 9876543213',
      role: 'Customer',
      status: 'Inactive',
      registeredDate: '2025-03-05'
    },
    {
      id: 5,
      name: 'Rajesh Verma',
      email: 'rajesh.verma@example.com',
      phone: '+91 9876543214',
      role: 'Technician',
      status: 'Active',
      registeredDate: '2024-10-15'
    },
    {
      id: 6,
      name: 'Suresh Yadav',
      email: 'suresh.yadav@example.com',
      phone: '+91 9876543215',
      role: 'Technician',
      status: 'Active',
      registeredDate: '2024-12-01'
    },
    {
      id: 7,
      name: 'Anita Singh',
      email: 'anita.singh@example.com',
      phone: '+91 9876543216',
      role: 'Admin',
      status: 'Active',
      registeredDate: '2024-09-20'
    }
  ]);

  // State for user details view/edit
  const [selectedUser, setSelectedUser] = useState(null);
  const [isViewingDetails, setIsViewingDetails] = useState(false);
  const [isEditingUser, setIsEditingUser] = useState(false);
  const [isAddingUser, setIsAddingUser] = useState(false);
  
  // Form data for editing/adding user
  const [formData, setFormData] = useState({
    id: null,
    name: '',
    email: '',
    phone: '',
    role: '',
    status: 'Active',
    password: '',
    confirmPassword: ''
  });

  // Filter states
  const [roleFilter, setRoleFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Available roles and statuses
  const roles = ['Admin', 'Technician', 'Customer'];
  const statuses = ['Active', 'Inactive'];

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // View user details
  const handleViewUser = (user) => {
    setSelectedUser(user);
    setIsViewingDetails(true);
    setIsEditingUser(false);
    setIsAddingUser(false);
  };

  // Edit user
  const handleEditUser = () => {
    setIsEditingUser(true);
    setFormData({
      id: selectedUser.id,
      name: selectedUser.name,
      email: selectedUser.email,
      phone: selectedUser.phone,
      role: selectedUser.role,
      status: selectedUser.status,
      password: '',
      confirmPassword: ''
    });
  };

  // Add new user
  const handleAddUser = () => {
    setIsAddingUser(true);
    setIsViewingDetails(false);
    setIsEditingUser(false);
    setSelectedUser(null);
    setFormData({
      id: users.length + 1,
      name: '',
      email: '',
      phone: '',
      role: '',
      status: 'Active',
      password: '',
      confirmPassword: ''
    });
  };

  // Close user details/form
  const handleCloseDetails = () => {
    setIsViewingDetails(false);
    setIsEditingUser(false);
    setIsAddingUser(false);
    setSelectedUser(null);
  };

  // Save user (add or update)
  const handleSaveUser = (e) => {
    e.preventDefault();
    
    // Validate form
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    
    if (isAddingUser) {
      // Add new user
      const newUser = {
        ...formData,
        registeredDate: new Date().toISOString().split('T')[0]
      };
      setUsers([...users, newUser]);
    } else if (isEditingUser) {
      // Update existing user
      setUsers(users.map(user => 
        user.id === formData.id ? { ...user, ...formData } : user
      ));
    }
    
    // Reset form and state
    handleCloseDetails();
  };

  // Toggle user status
  const handleToggleStatus = (id) => {
    setUsers(users.map(user => 
      user.id === id 
        ? { ...user, status: user.status === 'Active' ? 'Inactive' : 'Active' } 
        : user
    ));
  };

  // Filter users
  const filteredUsers = users.filter(user => {
    // Role filter
    if (roleFilter !== 'All' && user.role !== roleFilter) {
      return false;
    }
    
    // Status filter
    if (statusFilter !== 'All' && user.status !== statusFilter) {
      return false;
    }
    
    // Search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        user.name.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query) ||
        user.phone.includes(query)
      );
    }
    
    return true;
  });

  // Simulate data loading
  useEffect(() => {
    // In a real app, this would be an API call
    console.log('Users data loaded');
  }, []);

  return (
    <div className="admin-page">
      <div className="admin-header">
        <h1>User Management</h1>
        <p>Manage system users</p>
      </div>

      {isViewingDetails && !isEditingUser ? (
        <div className="dashboard-section">
          <div className="section-header">
            <h2>User Details</h2>
            <div>
              <button className="btn" onClick={handleEditUser}>
                <i className="fas fa-edit"></i> Edit
              </button>
              <button className="btn" onClick={handleCloseDetails} style={{ marginLeft: '10px' }}>
                <i className="fas fa-times"></i> Close
              </button>
            </div>
          </div>
          
          <div className="user-details">
            <div className="details-row">
              <div className="details-column">
                <div className="info-group">
                  <div className="info-label">Name:</div>
                  <div className="info-value">{selectedUser.name}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Email:</div>
                  <div className="info-value">{selectedUser.email}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Phone:</div>
                  <div className="info-value">{selectedUser.phone}</div>
                </div>
              </div>
              
              <div className="details-column">
                <div className="info-group">
                  <div className="info-label">Role:</div>
                  <div className="info-value">{selectedUser.role}</div>
                </div>
                <div className="info-group">
                  <div className="info-label">Status:</div>
                  <div className="info-value">
                    <span className={`status-badge ${selectedUser.status.toLowerCase()}`}>
                      {selectedUser.status}
                    </span>
                  </div>
                </div>
                <div className="info-group">
                  <div className="info-label">Registered Date:</div>
                  <div className="info-value">{selectedUser.registeredDate}</div>
                </div>
              </div>
            </div>
            
            <div className="form-actions">
              <button 
                className={`btn ${selectedUser.status === 'Active' ? 'btn-danger' : 'btn-success'}`}
                onClick={() => handleToggleStatus(selectedUser.id)}
              >
                {selectedUser.status === 'Active' ? 'Deactivate User' : 'Activate User'}
              </button>
            </div>
          </div>
        </div>
      ) : (isEditingUser || isAddingUser) ? (
        <div className="dashboard-section">
          <div className="section-header">
            <h2>{isAddingUser ? 'Add New User' : 'Edit User'}</h2>
            <button className="btn" onClick={handleCloseDetails}>
              <i className="fas fa-times"></i> Cancel
            </button>
          </div>
          
          <form className="admin-form" onSubmit={handleSaveUser}>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="name">Full Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="email">Email Address</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>
            
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="phone">Phone Number</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  required
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="role">Role</label>
                <select
                  id="role"
                  name="role"
                  value={formData.role}
                  onChange={handleInputChange}
                  required
                >
                  <option value="">Select Role</option>
                  {roles.map((role, index) => (
                    <option key={index} value={role}>{role}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="status">Status</label>
                <select
                  id="status"
                  name="status"
                  value={formData.status}
                  onChange={handleInputChange}
                  required
                >
                  {statuses.map((status, index) => (
                    <option key={index} value={status}>{status}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="password">Password {isEditingUser && '(Leave blank to keep current)'}</label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  required={isAddingUser}
                />
              </div>
              
              <div className="form-group">
                <label htmlFor="confirmPassword">Confirm Password</label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  required={isAddingUser}
                />
              </div>
            </div>
            
            <div className="form-actions">
              <button type="submit" className="btn btn-primary">
                {isAddingUser ? 'Add User' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      ) : (
        <>
          <div className="filters-section">
            <div className="search-box">
              <input 
                type="text" 
                placeholder="Search users..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="filter-controls">
              <div className="filter-group">
                <label>Role:</label>
                <select 
                  value={roleFilter} 
                  onChange={(e) => setRoleFilter(e.target.value)}
                >
                  <option value="All">All Roles</option>
                  {roles.map((role, index) => (
                    <option key={index} value={role}>{role}</option>
                  ))}
                </select>
              </div>
              
              <div className="filter-group">
                <label>Status:</label>
                <select 
                  value={statusFilter} 
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="All">All Statuses</option>
                  {statuses.map((status, index) => (
                    <option key={index} value={status}>{status}</option>
                  ))}
                </select>
              </div>
              
              <button 
                className="btn btn-sm"
                onClick={() => {
                  setRoleFilter('All');
                  setStatusFilter('All');
                  setSearchQuery('');
                }}
              >
                Clear Filters
              </button>
            </div>
          </div>
          
          <div className="section-header" style={{ marginBottom: '20px' }}>
            <h2>Users ({filteredUsers.length})</h2>
            <button className="btn btn-primary" onClick={handleAddUser}>
              <i className="fas fa-plus"></i> Add New User
            </button>
          </div>
          
          <div className="dashboard-section">
            <div className="table-container">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Registered Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map(user => (
                    <tr key={user.id}>
                      <td>{user.name}</td>
                      <td>{user.email}</td>
                      <td>{user.phone}</td>
                      <td>{user.role}</td>
                      <td>
                        <span className={`status-badge ${user.status.toLowerCase()}`}>
                          {user.status}
                        </span>
                      </td>
                      <td>{user.registeredDate}</td>
                      <td>
                        <button 
                          className="btn btn-sm"
                          onClick={() => handleViewUser(user)}
                        >
                          View
                        </button>
                        <button 
                          className={`btn btn-sm ${user.status === 'Active' ? 'btn-danger' : 'btn-success'}`}
                          onClick={() => handleToggleStatus(user.id)}
                          style={{ marginLeft: '5px' }}
                        >
                          {user.status === 'Active' ? 'Deactivate' : 'Activate'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}   </div>
  );
};

export default Users;
