import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { logout } from '../features/auth/authSlice';
import './ProfilePage.css';

const ProfilePage = () => {
  // Get user data from Redux
  const { user } = useSelector(state => state.auth);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  // Handle logout
  const handleLogout = () => {
    dispatch(logout());
    navigate('/');
  };
  
  // Mock user data with the authenticated user's information
  const [userData, setUserData] = useState({
    name: user?.fullName || 'Guest User',
    email: user?.email || 'guest@example.com',
    phone: user?.phone || '+91 9876543210',
    address: '123 Main Street, Jaipur, Rajasthan',
    vehicles: [
      {
        id: 1,
        make: 'Maruti Suzuki',
        model: 'Swift',
        year: '2019',
        registrationNumber: 'RJ14 AB 1234'
      },
      {
        id: 2,
        make: 'Honda',
        model: 'City',
        year: '2020',
        registrationNumber: 'RJ14 CD 5678'
      }
    ]
  });

  const [activeTab, setActiveTab] = useState('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: userData.name,
    email: userData.email,
    phone: userData.phone,
    address: userData.address
  });

  // Mock booking history
  const bookings = [
    {
      id: 'BK001',
      date: '2025-05-10',
      service: 'Express Service',
      vehicle: 'Maruti Suzuki Swift',
      status: 'Completed',
      amount: '₹2,499'
    },
    {
      id: 'BK002',
      date: '2025-04-15',
      service: 'AC Service',
      vehicle: 'Honda City',
      status: 'Completed',
      amount: '₹3,999'
    },
    {
      id: 'BK003',
      date: '2025-03-22',
      service: 'Periodic Maintenance',
      vehicle: 'Maruti Suzuki Swift',
      status: 'Completed',
      amount: '₹4,299'
    }
  ];

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const handleEditToggle = () => {
    if (isEditing) {
      // Save changes
      setUserData({
        ...userData,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        address: formData.address
      });
    }
    setIsEditing(!isEditing);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleAddVehicle = () => {
    // In a real app, this would open a modal or form to add a new vehicle
    alert('Add vehicle functionality would be implemented here');
  };

  return (
    <div className="profile-page">
      <div className="container">
        <div className="profile-header">
          <h1>My Account</h1>
          <p>Manage your profile and view your service history</p>
        </div>

        <div className="profile-content">
          <div className="profile-sidebar">
            <div className="user-info">
              <div className="user-avatar">
                {userData.name.charAt(0)}
              </div>
              <div className="user-name">{userData.name}</div>
            </div>
            
            <ul className="profile-tabs">
              <li 
                className={activeTab === 'profile' ? 'active' : ''}
                onClick={() => handleTabChange('profile')}
              >
                <i className="fas fa-user"></i> Profile
              </li>
              <li 
                className={activeTab === 'vehicles' ? 'active' : ''}
                onClick={() => handleTabChange('vehicles')}
              >
                <i className="fas fa-car"></i> My Vehicles
              </li>
              <li 
                className={activeTab === 'bookings' ? 'active' : ''}
                onClick={() => handleTabChange('bookings')}
              >
                <i className="fas fa-history"></i> Booking History
              </li>
              <li onClick={handleLogout}>
                <i className="fas fa-sign-out-alt"></i> Logout
              </li>
            </ul>
          </div>

          <div className="profile-main">
            {activeTab === 'profile' && (
              <div className="profile-details">
                <div className="section-header">
                  <h2>Personal Information</h2>
                  <button 
                    className="btn btn-sm"
                    onClick={handleEditToggle}
                  >
                    {isEditing ? 'Save Changes' : 'Edit Profile'}
                  </button>
                </div>

                {isEditing ? (
                  <div className="edit-form">
                    <div className="form-group">
                      <label>Full Name</label>
                      <input 
                        type="text" 
                        name="name" 
                        value={formData.name} 
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group">
                      <label>Email Address</label>
                      <input 
                        type="email" 
                        name="email" 
                        value={formData.email} 
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group">
                      <label>Phone Number</label>
                      <input 
                        type="tel" 
                        name="phone" 
                        value={formData.phone} 
                        onChange={handleInputChange}
                      />
                    </div>
                    <div className="form-group">
                      <label>Address</label>
                      <textarea 
                        name="address" 
                        value={formData.address} 
                        onChange={handleInputChange}
                      ></textarea>
                    </div>
                  </div>
                ) : (
                  <div className="info-list">
                    <div className="info-item">
                      <div className="info-label">Full Name</div>
                      <div className="info-value">{userData.name}</div>
                    </div>
                    <div className="info-item">
                      <div className="info-label">Email Address</div>
                      <div className="info-value">{userData.email}</div>
                    </div>
                    <div className="info-item">
                      <div className="info-label">Phone Number</div>
                      <div className="info-value">{userData.phone}</div>
                    </div>
                    <div className="info-item">
                      <div className="info-label">Address</div>
                      <div className="info-value">{userData.address}</div>
                    </div>
                  </div>
                )}

                <div className="section-divider"></div>

                <div className="section-header">
                  <h2>Account Security</h2>
                  <button className="btn btn-sm">Change Password</button>
                </div>
                <p className="security-info">
                  Your password was last changed 30 days ago. We recommend changing your password regularly for security.
                </p>
              </div>
            )}

            {activeTab === 'vehicles' && (
              <div className="vehicles-section">
                <div className="section-header">
                  <h2>My Vehicles</h2>
                  <button className="btn btn-sm" onClick={handleAddVehicle}>
                    <i className="fas fa-plus"></i> Add Vehicle
                  </button>
                </div>

                <div className="vehicles-list">
                  {userData.vehicles.map(vehicle => (
                    <div className="vehicle-card" key={vehicle.id}>
                      <div className="vehicle-icon">
                        <i className="fas fa-car"></i>
                      </div>
                      <div className="vehicle-details">
                        <h3>{vehicle.make} {vehicle.model} ({vehicle.year})</h3>
                        <p className="registration-number">{vehicle.registrationNumber}</p>
                        <div className="vehicle-actions">
                          <button className="btn btn-sm">Edit</button>
                          <button className="btn btn-sm btn-outline">Remove</button>
                          <Link to="/booking" className="btn btn-sm btn-primary">Book Service</Link>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'bookings' && (
              <div className="bookings-section">
                <div className="section-header">
                  <h2>Booking History</h2>
                </div>

                <div className="bookings-list">
                  <table className="bookings-table">
                    <thead>
                      <tr>
                        <th>Booking ID</th>
                        <th>Date</th>
                        <th>Service</th>
                        <th>Vehicle</th>
                        <th>Status</th>
                        <th>Amount</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bookings.map(booking => (
                        <tr key={booking.id}>
                          <td>{booking.id}</td>
                          <td>{booking.date}</td>
                          <td>{booking.service}</td>
                          <td>{booking.vehicle}</td>
                          <td>
                            <span className={`status-badge ${booking.status.toLowerCase()}`}>
                              {booking.status}
                            </span>
                          </td>
                          <td>{booking.amount}</td>
                          <td>
                            <button className="btn btn-sm">View Details</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
