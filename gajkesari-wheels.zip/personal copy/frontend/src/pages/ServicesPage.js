import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './ServicesPage.css';

// Import service icons (these would be actual images in a real implementation)
import expressServiceIcon from '../assets/images/services/express-service.svg';

const ServicesPage = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // In a real implementation, this would fetch data from the backend API
    // For now, we'll use mock data
    const mockServices = [
      {
        id: 1,
        name: 'Express 90-Minute Service',
        description: 'Get your car serviced in just 90 minutes with our express service.',
        category: 'EXPRESS_SERVICE',
        basePrice: 1999,
        imageUrl: expressServiceIcon,
        durationMinutes: 90
      },
      {
        id: 2,
        name: 'Periodic Service',
        description: 'Regular maintenance and servicing for your vehicle.',
        category: 'PERIODIC_SERVICE',
        basePrice: 2999,
        imageUrl: expressServiceIcon,
        durationMinutes: 180
      },
      {
        id: 3,
        name: 'AC Service',
        description: 'Professional car AC repair and maintenance.',
        category: 'AC_SERVICE',
        basePrice: 1499,
        imageUrl: expressServiceIcon,
        durationMinutes: 120
      },
      {
        id: 4,
        name: 'Car Spa & Cleaning',
        description: 'Professional car cleaning services.',
        category: 'CAR_SPA_CLEANING',
        basePrice: 999,
        imageUrl: expressServiceIcon,
        durationMinutes: 120
      },
      {
        id: 5,
        name: 'Denting & Painting',
        description: 'Expert dent removal and painting services.',
        category: 'DENTING_PAINTING',
        basePrice: 4999,
        imageUrl: expressServiceIcon,
        durationMinutes: 480
      },
      {
        id: 6,
        name: 'Battery Service',
        description: 'Battery check, repair and replacement.',
        category: 'BATTERY_SERVICE',
        basePrice: 799,
        imageUrl: expressServiceIcon,
        durationMinutes: 60
      },
      {
        id: 7,
        name: 'Windshield Service',
        description: 'Windshield repair and replacement.',
        category: 'WINDSHIELD_SERVICE',
        basePrice: 1299,
        imageUrl: expressServiceIcon,
        durationMinutes: 120
      },
      {
        id: 8,
        name: 'Car Detailing',
        description: 'Professional car detailing services.',
        category: 'CAR_DETAILING',
        basePrice: 2499,
        imageUrl: expressServiceIcon,
        durationMinutes: 240
      }
    ];

    setTimeout(() => {
      setServices(mockServices);
      setLoading(false);
    }, 500); // Simulate API delay
  }, []);

  if (loading) {
    return (
      <div className="services-page">
        <div className="container">
          <div className="loading">Loading services...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="services-page">
        <div className="container">
          <div className="error">Error loading services: {error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="services-page">
      <div className="container">
        <div className="page-header">
          <h1>Our Services</h1>
          <p>Comprehensive car care solutions for all your needs</p>
        </div>

        <div className="services-grid">
          {services.map((service) => (
            <div className="service-card" key={service.id}>
              <div className="service-icon">
                <img src={service.imageUrl} alt={service.name} />
              </div>
              <h3>{service.name}</h3>
              <p className="service-description">{service.description}</p>
              <div className="service-details">
                <div className="service-price">
                  <span className="price-label">Starting at</span>
                  <span className="price-value">₹{service.basePrice}</span>
                </div>
                <div className="service-duration">
                  <i className="fas fa-clock"></i>
                  <span>{service.durationMinutes} mins</span>
                </div>
              </div>
              <Link to={`/services/${service.id}`} className="btn btn-primary">
                View Details
              </Link>
            </div>
          ))}
        </div>

        <div className="service-categories">
          <h2>Browse Services by Category</h2>
          <div className="category-grid">
            <Link to="/services/category/express-service" className="category-card">
              <div className="category-icon">
                <i className="fas fa-bolt"></i>
              </div>
              <h3>Express Service</h3>
            </Link>
            <Link to="/services/category/periodic-service" className="category-card">
              <div className="category-icon">
                <i className="fas fa-calendar-check"></i>
              </div>
              <h3>Periodic Service</h3>
            </Link>
            <Link to="/services/category/ac-service" className="category-card">
              <div className="category-icon">
                <i className="fas fa-snowflake"></i>
              </div>
              <h3>AC Service</h3>
            </Link>
            <Link to="/services/category/car-spa" className="category-card">
              <div className="category-icon">
                <i className="fas fa-shower"></i>
              </div>
              <h3>Car Spa & Cleaning</h3>
            </Link>
            <Link to="/services/category/denting-painting" className="category-card">
              <div className="category-icon">
                <i className="fas fa-paint-roller"></i>
              </div>
              <h3>Denting & Painting</h3>
            </Link>
            <Link to="/services/category/battery-service" className="category-card">
              <div className="category-icon">
                <i className="fas fa-car-battery"></i>
              </div>
              <h3>Battery Service</h3>
            </Link>
          </div>
        </div>

        <div className="service-cta">
          <h2>Need Help Choosing the Right Service?</h2>
          <p>Our experts are ready to assist you in finding the perfect service for your vehicle.</p>
          <div className="cta-buttons">
            <Link to="/booking" className="btn btn-primary">
              Book a Service
            </Link>
            <a href="tel:+919844828528" className="btn btn-outline">
              Call Us
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServicesPage;
