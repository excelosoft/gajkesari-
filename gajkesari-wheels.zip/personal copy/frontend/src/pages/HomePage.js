import React from 'react';
import { Link } from 'react-router-dom';
import './HomePage.css';

// Import service icons (using the available SVG and placeholders for others)
import expressServiceIcon from '../assets/images/services/express-service.svg';
// Using the same SVG as a placeholder for other services until proper icons are available
import periodicServiceIcon from '../assets/images/services/express-service.svg';
import acServiceIcon from '../assets/images/services/express-service.svg';
import carSpaIcon from '../assets/images/services/express-service.svg';
import dentingPaintingIcon from '../assets/images/services/express-service.svg';
import batteryServiceIcon from '../assets/images/services/express-service.svg';
import windshieldServiceIcon from '../assets/images/services/express-service.svg';
import carDetailingIcon from '../assets/images/services/express-service.svg';

const HomePage = () => {
  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="container">
          <div className="hero-content">
            <div className="premium-tag">PREMIUM SERVICE</div>
            <h1>
              Get Your Car Serviced in Just <span className="highlight">90 Minutes!</span>
            </h1>
            <p>
              Experience lightning-fast car service with GajkesariWheels. Trusted mechanics, transparent pricing, and expert care—all at your convenience.
            </p>
            <div className="rating">
              <div className="stars">
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star-half-alt"></i>
              </div>
              <span>4.8/5 (120+ reviews)</span>
            </div>
            <div className="hero-features">
              <div className="feature">
                <div className="feature-icon">
                  <span className="time-icon">90</span>
                </div>
                <div className="feature-text">
                  <h3>EXPRESS SERVICE</h3>
                  <p>Minutes or Less</p>
                </div>
              </div>
              <div className="feature">
                <div className="feature-icon">
                  <i className="fas fa-clock"></i>
                </div>
                <div className="feature-text">
                  <h3>No More Waiting</h3>
                  <p>90 Mins vs 6+ Hours</p>
                </div>
              </div>
              <div className="feature">
                <div className="feature-icon">
                  <i className="fas fa-home"></i>
                </div>
                <div className="feature-text">
                  <h3>Zero Hassle</h3>
                  <p>100% doorstep service</p>
                </div>
              </div>
              <div className="feature">
                <div className="feature-icon">
                  <i className="fas fa-rupee-sign"></i>
                </div>
                <div className="feature-text">
                  <h3>Transparent Pricing</h3>
                  <p>No hidden fees</p>
                </div>
              </div>
            </div>
            <div className="hero-stats">
              <div className="stat">
                <h3>2K+</h3>
                <p>Happy Customers</p>
              </div>
              <div className="stat">
                <h3>4.8</h3>
                <p>Star Rating</p>
              </div>
              <div className="stat">
                <h3>5K+</h3>
                <p>Services Done</p>
              </div>
            </div>
            <div className="hero-cta">
              <Link to="/booking" className="btn btn-primary btn-lg">
                Book Now <i className="fas fa-arrow-right"></i>
              </Link>
              <button className="btn btn-outline btn-lg">
                Call Us
              </button>
            </div>
          </div>
          <div className="hero-image">
            {/* This would be an actual image in a real implementation */}
            <div className="image-placeholder"></div>
            <div className="emergency-service">
              <h3>Emergency Service</h3>
              <p>+91 844 828 5289</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="services-section">
        <div className="container">
          <div className="section-header">
            <h2>Our Services</h2>
            <p>Aapki Gaadi, Hamari Zimmedari</p>
          </div>

          <div className="express-service-card">
            <div className="super-fast-tag">Super Fast</div>
            <div className="express-content">
              <div className="express-icon">
                <img src={expressServiceIcon} alt="Express Car Service" />
              </div>
              <div className="express-details">
                <h3>Express Car Service</h3>
                <h4>Why Wait All Day?</h4>
                <p>
                  Car Service in <span className="highlight">90 MINS</span>, Nahi to <span className="highlight-free">FREEEE</span>
                </p>
                <p className="express-tagline">Fast, Affordable, Done Right!</p>
                <div className="express-features">
                  <div className="guarantee">
                    <i className="fas fa-stopwatch"></i> 90-MIN Guarantee
                  </div>
                  <Link to="/booking" className="btn btn-primary">
                    Schedule Slot Now
                  </Link>
                </div>
              </div>
            </div>
          </div>

          <div className="service-grid">
            <div className="service-card">
              <div className="service-icon">
                <img src={periodicServiceIcon} alt="Periodic Service" />
              </div>
              <h3>Periodic Service</h3>
              <p>Regular Maintenance and Servicing</p>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <img src={acServiceIcon} alt="AC Service" />
              </div>
              <h3>AC Service</h3>
              <p>Professional Car AC Repair and Maintenance</p>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <img src={carSpaIcon} alt="Car Spa & Cleaning" />
              </div>
              <h3>Car Spa & Cleaning</h3>
              <p>Professional Car Cleaning Services</p>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <img src={dentingPaintingIcon} alt="Denting & Painting" />
              </div>
              <h3>Denting & Painting</h3>
              <p>Expert Dent Removal and Painting Services</p>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <img src={batteryServiceIcon} alt="Battery Service" />
              </div>
              <h3>Battery Service</h3>
              <p>Battery Check, Repair and Replacement</p>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <img src={windshieldServiceIcon} alt="Windshield Service" />
              </div>
              <h3>Windshield Service</h3>
              <p>Windshield Repair and Replacement</p>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <img src={carDetailingIcon} alt="Car Detailing" />
              </div>
              <h3>Car Detailing</h3>
              <p>Professional Car Detailing Services</p>
            </div>
            <div className="service-card">
              <div className="service-icon">
                <img src={carDetailingIcon} alt="Tyre Service" />
              </div>
              <h3>Tyre Service</h3>
              <p>Tyre Maintenance and Replacement</p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="how-it-works-section">
        <div className="container">
          <div className="section-header">
            <h2>How It Works</h2>
          </div>

          <div className="process-steps">
            <div className="step">
              <div className="step-icon">
                <i className="fas fa-calendar-alt"></i>
              </div>
              <h3>Book Online</h3>
              <p>Schedule your express service in seconds</p>
            </div>
            <div className="step">
              <div className="step-icon">
                <i className="fas fa-car"></i>
              </div>
              <h3>Express Pickup</h3>
              <p>Optional doorstep pickup service</p>
            </div>
            <div className="step">
              <div className="step-icon">
                <i className="fas fa-tools"></i>
              </div>
              <h3>90-Minute Service</h3>
              <p>Expert mechanics work simultaneously</p>
            </div>
          </div>

          <div className="process-details">
            <div className="detail-step">
              <div className="detail-icon">
                <i className="fas fa-mobile-alt"></i>
              </div>
              <h3>Real-Time Updates</h3>
              <p>Track progress with photos & videos</p>
            </div>
            <div className="detail-step">
              <div className="detail-icon">
                <i className="fas fa-user-tie"></i>
              </div>
              <h3>GajkesariWheels's Trained Mechanics</h3>
              <p>Expert technicians with specialized training</p>
            </div>
            <div className="detail-step">
              <div className="detail-icon">
                <i className="fas fa-cog"></i>
              </div>
              <h3>Genuine Parts Used</h3>
              <p>Quality parts for optimal performance</p>
            </div>
          </div>
        </div>
      </section>

      {/* 90-Minute Service Process */}
      <section className="service-process-section">
        <div className="container">
          <div className="section-header">
            <h2>Our 90-Minute Service Process</h2>
            <p>Speed meets precision with our innovative parallel processing system</p>
          </div>

          <div className="process-timeline">
            <div className="timeline-step">
              <div className="timeline-icon">
                <i className="fas fa-search"></i>
              </div>
              <h3>Initial Inspection</h3>
              <p className="time">5 mins</p>
              <p>Quick but thorough inspection to identify service requirements</p>
            </div>
            <div className="timeline-step">
              <div className="timeline-icon">
                <i className="fas fa-clipboard-list"></i>
              </div>
              <h3>Service Planning</h3>
              <p className="time">5 mins</p>
              <p>Efficient allocation of tasks to specialized technicians</p>
            </div>
            <div className="timeline-step">
              <div className="timeline-icon">
                <i className="fas fa-cogs"></i>
              </div>
              <h3>Parallel Processing</h3>
              <p className="time">70 mins</p>
              <p>Multiple services performed simultaneously by expert teams</p>
            </div>
            <div className="timeline-step">
              <div className="timeline-icon">
                <i className="fas fa-clipboard-check"></i>
              </div>
              <h3>Quality Check</h3>
              <p className="time">10 mins</p>
              <p>Comprehensive inspection of all serviced components</p>
            </div>
          </div>
        </div>
      </section>

      {/* Quality Assurance Section */}
      <section className="quality-section">
        <div className="container">
          <div className="section-header">
            <h2>Quality Assurance</h2>
          </div>

          <div className="quality-features">
            <div className="quality-feature">
              <div className="quality-icon">
                <i className="fas fa-certificate"></i>
              </div>
              <h3>Certified Technicians</h3>
              <p>Every service performed by OEM-trained professionals</p>
            </div>
            <div className="quality-feature">
              <div className="quality-icon">
                <i className="fas fa-check-circle"></i>
              </div>
              <h3>Quality Parts</h3>
              <p>Only genuine or OEM-approved parts used</p>
            </div>
            <div className="quality-feature">
              <div className="quality-icon">
                <i className="fas fa-file-alt"></i>
              </div>
              <h3>Digital Documentation</h3>
              <p>Complete service history with photos and videos</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="cta-section">
        <div className="container">
          <h2>Ready to Experience Express Service?</h2>
          <Link to="/booking" className="btn btn-primary btn-lg">
            Book Your Express Service
          </Link>
          <p>No prepayment required. Book now, pay after service.</p>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="testimonials-section">
        <div className="container">
          <div className="section-header">
            <h2>Customer Reviews Near You</h2>
          </div>

          <div className="testimonial-card">
            <div className="customer-info">
              <div className="customer-initial">L</div>
              <div className="customer-name">
                <h3>Leela</h3>
                <div className="stars">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                </div>
              </div>
            </div>
            <p className="testimonial-text">
              "GajkesariWheels's express service was great! My Maruti was back on the road quickly. No issues at all. Fast and efficient, just what I needed!"
            </p>
          </div>
        </div>
      </section>

      {/* India Section */}
      <section className="india-section">
        <div className="container">
          <h2>
            Revolutionizing <span className="highlight">Car Care</span> in India
          </h2>
          <p>
            GajkesariWheels is transforming how Indians maintain their vehicles with technology, transparency, and trust.
          </p>
        </div>
      </section>

      {/* Mission & Vision Section */}
      <section className="mission-vision-section">
        <div className="container">
          <div className="mission-card">
            <div className="mission-icon">
              <i className="fas fa-bolt"></i>
            </div>
            <div className="mission-content">
              <h3>Our Mission</h3>
              <p>
                To revolutionize car maintenance with our GajkesariWheels Express 90 Mins Car Service, creating a hyperlocal revolution that saves time, ensures quality, and transforms the traditional car service model through innovative technology and exceptional customer experience.
              </p>
            </div>
          </div>

          <div className="vision-card">
            <div className="vision-icon">
              <i className="fas fa-star"></i>
            </div>
            <div className="vision-content">
              <h3>Our Vision</h3>
              <p>
                To become India's most trusted automotive care platform, creating a seamless ecosystem where vehicle maintenance is no longer a burden but a delightful experience for every car owner.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonial Quote */}
      <section className="testimonial-quote-section">
        <div className="container">
          <div className="quote-box">
            <p>
              People love our 90 Mins Express Service. Once you try it, there's no going back to <span className="highlight">wasting</span> full day on traditional car service.
            </p>
            <div className="quote-rating">
              <div className="stars">
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
                <i className="fas fa-star"></i>
              </div>
              <p>From our happy customers</p>
            </div>
          </div>
        </div>
      </section>

      {/* Advantage Section */}
      <section className="advantage-section">
        <div className="container">
          <div className="advantage-content">
            <div className="advantage-image">
              {/* This would be an actual image in a real implementation */}
              <div className="image-placeholder"></div>
            </div>
            <div className="advantage-details">
              <h2>The GajkesariWheels <span className="highlight">Advantage</span></h2>
              <p>
                GajkesariWheels isn't just another car service platform. We're a complete car care ecosystem that puts you in control while delivering unmatched quality and convenience.
              </p>
              <div className="advantage-features">
                <div className="advantage-feature">
                  <div className="feature-icon">
                    <i className="fas fa-users"></i>
                  </div>
                  <div className="feature-content">
                    <h3>Curated Network of Experts</h3>
                    <p>Access our rigorously vetted network of professional workshops and technicians</p>
                  </div>
                </div>
                <div className="advantage-feature">
                  <div className="feature-icon">
                    <i className="fas fa-shield-alt"></i>
                  </div>
                  <div className="feature-content">
                    <h3>Quality Guarantee</h3>
                    <p>Every service backed by our quality assurance and customer satisfaction promise</p>
                  </div>
                </div>
                <div className="advantage-feature">
                  <div className="feature-icon">
                    <i className="fas fa-clock"></i>
                  </div>
                  <div className="feature-content">
                    <h3>Real-Time Tracking</h3>
                    <p>Monitor your service progress with our transparent real-time tracking system</p>
                  </div>
                </div>
                <div className="advantage-feature">
                  <div className="feature-icon">
                    <i className="fas fa-home"></i>
                  </div>
                  <div className="feature-content">
                    <h3>Doorstep Convenience</h3>
                    <p>Enjoy pickup and drop services for ultimate convenience</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* App Promo Section */}
      <section className="app-promo-section">
        <div className="container">
          <h2>Dropping Soon!</h2>
          <p>Get ready for the GajkesariWheels Mobile App</p>
          <div className="app-buttons">
            <a href="#" className="app-button">
              <i className="fab fa-apple"></i> Download on the App Store
            </a>
            <a href="#" className="app-button">
              <i className="fab fa-google-play"></i> GET IT ON Google Play
            </a>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="faq-section">
        <div className="container">
          <div className="section-header">
            <h2>Common Car Service Questions</h2>
          </div>

          <div className="faq-grid">
            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle"></i>
                <h3>How do I find a car service near me?</h3>
                <i className="fas fa-chevron-down"></i>
              </div>
              {/* FAQ answer would be shown on click in a real implementation */}
            </div>
            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle"></i>
                <h3>Do you provide car repair and maintenance services?</h3>
                <i className="fas fa-chevron-down"></i>
              </div>
            </div>
            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle"></i>
                <h3>Does GajkesariWheels offer an Express 90-minute service?</h3>
                <i className="fas fa-chevron-down"></i>
              </div>
            </div>
            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle"></i>
                <h3>Can I use the GajkesariWheels app to schedule maintenance?</h3>
                <i className="fas fa-chevron-down"></i>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="contact-section">
        <div className="container">
          <div className="section-header">
            <h2>Contact Us</h2>
            <p>Get in touch with our expert team</p>
          </div>

          <div className="contact-info">
            <div className="contact-card">
              <div className="contact-icon">
                <i className="fas fa-map-marker-alt"></i>
              </div>
              <h3>Location</h3>
              <p>GajkesariWheels HQ, 21, Purani Chungi, Jaipur, Rajasthan</p>
            </div>
            <div className="contact-card">
              <div className="contact-icon">
                <i className="fas fa-phone-alt"></i>
              </div>
              <h3>Phone</h3>
              <p>+91 844 828 5289</p>
            </div>
            <div className="contact-card">
              <div className="contact-icon">
                <i className="fas fa-envelope"></i>
              </div>
              <h3>Email</h3>
              <p>contact@gajkesariwheels.com</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
