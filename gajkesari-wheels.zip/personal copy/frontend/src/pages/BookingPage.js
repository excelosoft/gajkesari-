import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './BookingPage.css';

// Import service icons (these would be actual images in a real implementation)
import expressServiceIcon from '../assets/images/services/express-service.svg';

const BookingPage = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    carModel: '',
    carBrand: '',
    carYear: '',
    serviceId: '',
    appointmentDate: '',
    appointmentTime: '',
    isDoorstep: false,
    address: '',
    name: '',
    email: '',
    phone: '',
    notes: ''
  });
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [availableSlots, setAvailableSlots] = useState([]);
  const [selectedDate, setSelectedDate] = useState('');

  useEffect(() => {
    // In a real implementation, this would fetch data from the backend API
    // For now, we'll use mock data
    const mockServices = [
      {
        id: 1,
        name: 'Express 90-Minute Service',
        description: 'Get your car serviced in just 90 minutes with our express service.',
        category: 'EXPRESS_SERVICE',
        basePrice: 1999,
        imageUrl: expressServiceIcon,
        durationMinutes: 90
      },
      {
        id: 2,
        name: 'Periodic Service',
        description: 'Regular maintenance and servicing for your vehicle.',
        category: 'PERIODIC_SERVICE',
        basePrice: 2999,
        imageUrl: expressServiceIcon,
        durationMinutes: 180
      },
      {
        id: 3,
        name: 'AC Service',
        description: 'Professional car AC repair and maintenance.',
        category: 'AC_SERVICE',
        basePrice: 1499,
        imageUrl: expressServiceIcon,
        durationMinutes: 120
      },
      {
        id: 4,
        name: 'Car Spa & Cleaning',
        description: 'Professional car cleaning services.',
        category: 'CAR_SPA_CLEANING',
        basePrice: 999,
        imageUrl: expressServiceIcon,
        durationMinutes: 120
      }
    ];

    setTimeout(() => {
      setServices(mockServices);
      setLoading(false);
    }, 500); // Simulate API delay
  }, []);

  useEffect(() => {
    // Generate mock available slots when date changes
    if (selectedDate) {
      const mockSlots = [
        '09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', 
        '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM'
      ];
      setAvailableSlots(mockSlots);
    }
  }, [selectedDate]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });

    if (name === 'appointmentDate') {
      setSelectedDate(value);
    }
  };

  const handleServiceSelect = (serviceId) => {
    setFormData({
      ...formData,
      serviceId
    });
  };

  const handleNextStep = () => {
    setCurrentStep(currentStep + 1);
  };

  const handlePrevStep = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // In a real implementation, this would send the data to the backend API
    console.log('Booking submitted:', formData);
    // Move to confirmation step
    setCurrentStep(5);
  };

  const renderCarDetails = () => {
    return (
      <div className="booking-step">
        <h2>Step 1: Car Details</h2>
        <div className="form-group">
          <label htmlFor="carBrand" className="form-label">Car Brand</label>
          <select
            id="carBrand"
            name="carBrand"
            className="form-control"
            value={formData.carBrand}
            onChange={handleInputChange}
            required
          >
            <option value="">Select Car Brand</option>
            <option value="Maruti Suzuki">Maruti Suzuki</option>
            <option value="Hyundai">Hyundai</option>
            <option value="Tata">Tata</option>
            <option value="Mahindra">Mahindra</option>
            <option value="Honda">Honda</option>
            <option value="Toyota">Toyota</option>
            <option value="Kia">Kia</option>
            <option value="Ford">Ford</option>
            <option value="Volkswagen">Volkswagen</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="carModel" className="form-label">Car Model</label>
          <input
            type="text"
            id="carModel"
            name="carModel"
            className="form-control"
            value={formData.carModel}
            onChange={handleInputChange}
            placeholder="e.g., Swift, i20, Nexon"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="carYear" className="form-label">Manufacturing Year</label>
          <select
            id="carYear"
            name="carYear"
            className="form-control"
            value={formData.carYear}
            onChange={handleInputChange}
            required
          >
            <option value="">Select Year</option>
            {Array.from({ length: 25 }, (_, i) => new Date().getFullYear() - i).map(year => (
              <option key={year} value={year}>{year}</option>
            ))}
          </select>
        </div>
        <div className="form-actions">
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleNextStep}
            disabled={!formData.carBrand || !formData.carModel || !formData.carYear}
          >
            Next: Select Service
          </button>
        </div>
      </div>
    );
  };

  const renderServiceSelection = () => {
    return (
      <div className="booking-step">
        <h2>Step 2: Select Service</h2>
        <div className="service-selection">
          {services.map(service => (
            <div
              key={service.id}
              className={`service-option ${formData.serviceId === service.id ? 'selected' : ''}`}
              onClick={() => handleServiceSelect(service.id)}
            >
              <div className="service-option-content">
                <div className="service-option-icon">
                  <img src={service.imageUrl} alt={service.name} />
                </div>
                <div className="service-option-details">
                  <h3>{service.name}</h3>
                  <p>{service.description}</p>
                  <div className="service-option-meta">
                    <span className="price">₹{service.basePrice}</span>
                    <span className="duration">{service.durationMinutes} mins</span>
                  </div>
                </div>
              </div>
              <div className="service-option-select">
                {formData.serviceId === service.id ? (
                  <i className="fas fa-check-circle"></i>
                ) : (
                  <i className="far fa-circle"></i>
                )}
              </div>
            </div>
          ))}
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-outline" onClick={handlePrevStep}>
            Back
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleNextStep}
            disabled={!formData.serviceId}
          >
            Next: Schedule Appointment
          </button>
        </div>
      </div>
    );
  };

  const renderScheduling = () => {
    // Generate dates for the next 7 days
    const dates = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() + i);
      return date.toISOString().split('T')[0];
    });

    return (
      <div className="booking-step">
        <h2>Step 3: Schedule Appointment</h2>
        <div className="form-group">
          <label className="form-label">Select Date</label>
          <div className="date-selection">
            {dates.map(date => {
              const dateObj = new Date(date);
              const formattedDate = dateObj.toLocaleDateString('en-US', {
                weekday: 'short',
                month: 'short',
                day: 'numeric'
              });
              return (
                <div
                  key={date}
                  className={`date-option ${formData.appointmentDate === date ? 'selected' : ''}`}
                  onClick={() => handleInputChange({ target: { name: 'appointmentDate', value: date } })}
                >
                  <div className="date-day">{formattedDate.split(',')[0]}</div>
                  <div className="date-number">{formattedDate.split(' ')[1]}</div>
                  <div className="date-month">{formattedDate.split(' ')[0]}</div>
                </div>
              );
            })}
          </div>
        </div>
        {formData.appointmentDate && (
          <div className="form-group">
            <label className="form-label">Select Time Slot</label>
            <div className="time-selection">
              {availableSlots.map(slot => (
                <div
                  key={slot}
                  className={`time-option ${formData.appointmentTime === slot ? 'selected' : ''}`}
                  onClick={() => handleInputChange({ target: { name: 'appointmentTime', value: slot } })}
                >
                  {slot}
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="form-group">
          <div className="doorstep-option">
            <input
              type="checkbox"
              id="isDoorstep"
              name="isDoorstep"
              checked={formData.isDoorstep}
              onChange={handleInputChange}
            />
            <label htmlFor="isDoorstep">Doorstep Service (Additional ₹299)</label>
          </div>
        </div>
        {formData.isDoorstep && (
          <div className="form-group">
            <label htmlFor="address" className="form-label">Service Address</label>
            <textarea
              id="address"
              name="address"
              className="form-control"
              value={formData.address}
              onChange={handleInputChange}
              placeholder="Enter your complete address"
              rows="3"
              required={formData.isDoorstep}
            ></textarea>
          </div>
        )}
        <div className="form-actions">
          <button type="button" className="btn btn-outline" onClick={handlePrevStep}>
            Back
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleNextStep}
            disabled={!formData.appointmentDate || !formData.appointmentTime || (formData.isDoorstep && !formData.address)}
          >
            Next: Your Details
          </button>
        </div>
      </div>
    );
  };

  const renderCustomerDetails = () => {
    return (
      <div className="booking-step">
        <h2>Step 4: Your Details</h2>
        <div className="form-group">
          <label htmlFor="name" className="form-label">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            className="form-control"
            value={formData.name}
            onChange={handleInputChange}
            placeholder="Enter your full name"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email" className="form-label">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            className="form-control"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="Enter your email address"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone" className="form-label">Phone Number</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            className="form-control"
            value={formData.phone}
            onChange={handleInputChange}
            placeholder="Enter your phone number"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="notes" className="form-label">Additional Notes (Optional)</label>
          <textarea
            id="notes"
            name="notes"
            className="form-control"
            value={formData.notes}
            onChange={handleInputChange}
            placeholder="Any specific requirements or issues with your car"
            rows="3"
          ></textarea>
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-outline" onClick={handlePrevStep}>
            Back
          </button>
          <button
            type="submit"
            className="btn btn-primary"
            onClick={handleSubmit}
            disabled={!formData.name || !formData.email || !formData.phone}
          >
            Confirm Booking
          </button>
        </div>
      </div>
    );
  };

  const renderConfirmation = () => {
    const selectedService = services.find(service => service.id === formData.serviceId);
    
    return (
      <div className="booking-step confirmation-step">
        <div className="confirmation-icon">
          <i className="fas fa-check-circle"></i>
        </div>
        <h2>Booking Confirmed!</h2>
        <p className="confirmation-message">
          Thank you for booking with GajkesariWheels. Your service has been scheduled successfully.
        </p>
        
        <div className="booking-summary">
          <h3>Booking Details</h3>
          <div className="summary-item">
            <span className="summary-label">Service:</span>
            <span className="summary-value">{selectedService?.name}</span>
          </div>
          <div className="summary-item">
            <span className="summary-label">Date & Time:</span>
            <span className="summary-value">
              {new Date(formData.appointmentDate).toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })} at {formData.appointmentTime}
            </span>
          </div>
          <div className="summary-item">
            <span className="summary-label">Vehicle:</span>
            <span className="summary-value">{formData.carBrand} {formData.carModel} ({formData.carYear})</span>
          </div>
          <div className="summary-item">
            <span className="summary-label">Service Type:</span>
            <span className="summary-value">{formData.isDoorstep ? 'Doorstep Service' : 'Workshop Service'}</span>
          </div>
          <div className="summary-item">
            <span className="summary-label">Total Amount:</span>
            <span className="summary-value price">
              ₹{selectedService?.basePrice + (formData.isDoorstep ? 299 : 0)}
            </span>
          </div>
        </div>
        
        <div className="confirmation-actions">
          <p>A confirmation has been sent to your email and phone number.</p>
          <div className="action-buttons">
            <Link to="/" className="btn btn-primary">
              Back to Home
            </Link>
            <a href="https://wa.me/919844828528" className="btn btn-outline">
              <i className="fab fa-whatsapp"></i> Contact on WhatsApp
            </a>
          </div>
        </div>
      </div>
    );
  };

  const renderStepIndicator = () => {
    return (
      <div className="step-indicator">
        <div className={`step-item ${currentStep >= 1 ? 'active' : ''} ${currentStep > 1 ? 'completed' : ''}`}>
          <div className="step-number">1</div>
          <div className="step-title">Car Details</div>
        </div>
        <div className={`step-item ${currentStep >= 2 ? 'active' : ''} ${currentStep > 2 ? 'completed' : ''}`}>
          <div className="step-number">2</div>
          <div className="step-title">Select Service</div>
        </div>
        <div className={`step-item ${currentStep >= 3 ? 'active' : ''} ${currentStep > 3 ? 'completed' : ''}`}>
          <div className="step-number">3</div>
          <div className="step-title">Schedule</div>
        </div>
        <div className={`step-item ${currentStep >= 4 ? 'active' : ''} ${currentStep > 4 ? 'completed' : ''}`}>
          <div className="step-number">4</div>
          <div className="step-title">Your Details</div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="booking-page">
        <div className="container">
          <div className="loading">Loading booking form...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="booking-page">
        <div className="container">
          <div className="error">Error loading booking form: {error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="booking-page">
      <div className="container">
        <div className="booking-header">
          <h1>Book Your Car Service</h1>
          <p>Schedule a service appointment in just a few easy steps</p>
        </div>
        
        {currentStep < 5 && renderStepIndicator()}
        
        <div className="booking-form-container">
          <form className="booking-form">
            {currentStep === 1 && renderCarDetails()}
            {currentStep === 2 && renderServiceSelection()}
            {currentStep === 3 && renderScheduling()}
            {currentStep === 4 && renderCustomerDetails()}
            {currentStep === 5 && renderConfirmation()}
          </form>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;
