import axios from 'axios';
import { mockSignIn, mockSignUp } from './features/auth/mockAuth';

// Create axios instance
const axiosInstance = axios.create();

// Add a request interceptor
axiosInstance.interceptors.request.use(
  async (config) => {
    // Get token from localStorage
    const token = localStorage.getItem('token');
    
    // If token exists, add to headers
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add a request interceptor to intercept auth requests before they're sent
axiosInstance.interceptors.request.use(
  async (config) => {
    // Get token from localStorage
    const token = localStorage.getItem('token');
    
    // If token exists, add to headers
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    // Check if this is an auth endpoint and handle it directly
    if (config.url === '/api/auth/signin') {
      try {
        // Extract username and password from request
        let username, password;
        
        if (typeof config.data === 'string') {
          // If data is a string, try to parse it as JSON
          const parsedData = JSON.parse(config.data);
          username = parsedData.username;
          password = parsedData.password;
        } else if (typeof config.data === 'object') {
          // If data is already an object, use it directly
          username = config.data.username;
          password = config.data.password;
        }
        
        // Use mock sign in
        const userData = mockSignIn(username, password);
        
        // Create a mock response
        const mockResponse = {
          data: userData,
          status: 200,
          statusText: 'OK',
          headers: {},
          config: config
        };
        
        // Store token in localStorage
        localStorage.setItem('token', userData.token);
        
        // Throw a special error to skip the actual request
        const customError = new Error('Mock response');
        customError.mockResponse = mockResponse;
        throw customError;
      } catch (error) {
        if (error.mockResponse) {
          throw error; // This will be caught by the response interceptor
        }
        
        // If it's a real error from our mock auth, create a mock error response
        const mockErrorResponse = {
          response: {
            data: {
              message: error.message
            },
            status: 401,
            statusText: 'Unauthorized',
            headers: {},
            config: config
          }
        };
        
        // Throw a special error to skip the actual request
        const customError = new Error('Mock error response');
        customError.mockErrorResponse = mockErrorResponse;
        throw customError;
      }
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add a response interceptor to handle mock authentication
axiosInstance.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    // Check if this is our special mock response error
    if (error.mockResponse) {
      return Promise.resolve(error.mockResponse);
    }
    
    // Check if this is our special mock error response
    if (error.mockErrorResponse) {
      return Promise.reject(error.mockErrorResponse);
    }
    
    const originalRequest = error.config;
    
    // If the error is from our API and we haven't retried yet
    if ((error.response?.status === 404 || error.response?.status === 500 || error.code === 'ECONNREFUSED') && !originalRequest._retry) {
      originalRequest._retry = true;
      
      // Check if this is a signup endpoint
      if (originalRequest.url === '/api/auth/signup') {
        try {
          // Extract user data from request
          let userData;
          
          if (typeof originalRequest.data === 'string') {
            // If data is a string, try to parse it as JSON
            userData = JSON.parse(originalRequest.data);
          } else if (typeof originalRequest.data === 'object') {
            // If data is already an object, use it directly
            userData = originalRequest.data;
          }
          
          // Use mock sign up
          const result = mockSignUp(userData);
          
          // Return a mock successful response
          return Promise.resolve({
            data: result,
            status: 200,
            statusText: 'OK',
            headers: {},
            config: originalRequest
          });
        } catch (error) {
          // Return a mock error response
          return Promise.reject({
            response: {
              data: {
                message: error.message
              },
              status: 400,
              statusText: 'Bad Request',
              headers: {},
              config: originalRequest
            }
          });
        }
      }
    }
    
    return Promise.reject(error);
  }
);

// Replace the global axios instance with our configured instance
axios.defaults.baseURL = '';
axios.defaults.headers.common = axiosInstance.defaults.headers.common;
axios.interceptors.request = axiosInstance.interceptors.request;
axios.interceptors.response = axiosInstance.interceptors.response;

export default axiosInstance;
