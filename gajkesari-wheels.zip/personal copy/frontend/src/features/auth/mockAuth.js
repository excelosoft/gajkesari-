// Mock user data for demo purposes - using the same data as in Users.js
export const mockUsers = [
  {
    id: 1,
    username: 'rahul.sharma',
    email: 'rahul.sharma@example.com',
    password: 'password123',
    fullName: 'Rahul Sharma',
    roles: ['ROLE_USER'],
    role: 'Customer'
  },
  {
    id: 2,
    username: 'priya.patel',
    email: 'priya.patel@example.com',
    password: 'password123',
    fullName: 'Priya Patel',
    roles: ['ROLE_USER'],
    role: 'Customer'
  },
  {
    id: 3,
    username: 'amit.kumar',
    email: 'amit.kumar@example.com',
    password: 'password123',
    fullName: 'Amit Kumar',
    roles: ['ROLE_TECHNICIAN'],
    role: 'Technician'
  },
  {
    id: 4,
    username: 'neha.gupta',
    email: 'neha.gupta@example.com',
    password: 'password123',
    fullName: 'Neha Gupta',
    roles: ['ROLE_USER'],
    role: 'Customer'
  },
  {
    id: 5,
    username: 'rajesh.verma',
    email: 'rajesh.verma@example.com',
    password: 'password123',
    fullName: 'Rajesh Verma',
    roles: ['ROLE_TECHNICIAN'],
    role: 'Technician'
  },
  {
    id: 6,
    username: 'suresh.yadav',
    email: 'suresh.yadav@example.com',
    password: 'password123',
    fullName: 'Suresh Yadav',
    roles: ['ROLE_TECHNICIAN'],
    role: 'Technician'
  },
  {
    id: 7,
    username: 'anita.singh',
    email: 'anita.singh@example.com',
    password: 'password123',
    fullName: 'Anita Singh',
    roles: ['ROLE_ADMIN'],
    role: 'Admin'
  }
];

// Mock authentication functions
export const mockSignIn = (username, password) => {
  // Find user by username or email
  const user = mockUsers.find(
    u => u.username === username || u.email === username
  );
  
  // Check if user exists and password matches
  if (!user || user.password !== password) {
    throw new Error('Invalid username or password');
  }
  
  // Create mock token
  const token = `mock-jwt-token-${user.id}-${Date.now()}`;
  
  // Return mock response
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    fullName: user.fullName,
    roles: user.roles,
    token: token
  };
};

export const mockSignUp = (userData) => {
  // Check if username or email already exists
  const userExists = mockUsers.some(
    u => u.username === userData.username || u.email === userData.email
  );
  
  if (userExists) {
    throw new Error('Username or email already in use');
  }
  
  // Create new user
  const newUser = {
    id: mockUsers.length + 1,
    ...userData,
    roles: ['ROLE_USER']
  };
  
  // Add to mock users (in a real app, this would persist to a database)
  mockUsers.push(newUser);
  
  return {
    message: 'User registered successfully!'
  };
};
