import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const initialState = {
  services: [],
  service: null,
  isLoading: false,
  error: null
};

// Get all services
export const getServices = createAsyncThunk(
  'services/getServices',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get('/api/services');
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch services. Please try again.'
      );
    }
  }
);

// Get service by ID
export const getServiceById = createAsyncThunk(
  'services/getServiceById',
  async (id, { rejectWithValue }) => {
    try {
      const response = await axios.get(`/api/services/${id}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch service details. Please try again.'
      );
    }
  }
);

// Get services by category
export const getServicesByCategory = createAsyncThunk(
  'services/getServicesByCategory',
  async (category, { rejectWithValue }) => {
    try {
      const response = await axios.get(`/api/services/category/${category}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch services by category. Please try again.'
      );
    }
  }
);

// Create service (admin/manager only)
export const createService = createAsyncThunk(
  'services/createService',
  async (serviceData, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.post('/api/services', serviceData, config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to create service. Please try again.'
      );
    }
  }
);

// Update service (admin/manager only)
export const updateService = createAsyncThunk(
  'services/updateService',
  async ({ id, serviceData }, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.put(`/api/services/${id}`, serviceData, config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to update service. Please try again.'
      );
    }
  }
);

// Delete service (admin only)
export const deleteService = createAsyncThunk(
  'services/deleteService',
  async (id, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };
      
      await axios.delete(`/api/services/${id}`, config);
      return id;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to delete service. Please try again.'
      );
    }
  }
);

const serviceSlice = createSlice({
  name: 'services',
  initialState,
  reducers: {
    clearServiceError: (state) => {
      state.error = null;
    },
    clearService: (state) => {
      state.service = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Get all services
      .addCase(getServices.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getServices.fulfilled, (state, action) => {
        state.isLoading = false;
        state.services = action.payload;
      })
      .addCase(getServices.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Get service by ID
      .addCase(getServiceById.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getServiceById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.service = action.payload;
      })
      .addCase(getServiceById.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Get services by category
      .addCase(getServicesByCategory.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getServicesByCategory.fulfilled, (state, action) => {
        state.isLoading = false;
        state.services = action.payload;
      })
      .addCase(getServicesByCategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Create service
      .addCase(createService.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(createService.fulfilled, (state, action) => {
        state.isLoading = false;
        state.services.push(action.payload);
      })
      .addCase(createService.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Update service
      .addCase(updateService.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateService.fulfilled, (state, action) => {
        state.isLoading = false;
        state.services = state.services.map(service =>
          service.id === action.payload.id ? action.payload : service
        );
        state.service = action.payload;
      })
      .addCase(updateService.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Delete service
      .addCase(deleteService.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(deleteService.fulfilled, (state, action) => {
        state.isLoading = false;
        state.services = state.services.filter(service => service.id !== action.payload);
      })
      .addCase(deleteService.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  }
});

export const { clearServiceError, clearService } = serviceSlice.actions;

export default serviceSlice.reducer;
