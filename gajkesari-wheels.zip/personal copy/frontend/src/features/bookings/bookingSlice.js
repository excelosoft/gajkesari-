import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const initialState = {
  bookings: [],
  booking: null,
  isLoading: false,
  error: null,
  success: false
};

// Get all bookings (admin/manager only)
export const getBookings = createAsyncThunk(
  'bookings/getBookings',
  async (_, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.get('/api/bookings', config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch bookings. Please try again.'
      );
    }
  }
);

// Get booking by ID
export const getBookingById = createAsyncThunk(
  'bookings/getBookingById',
  async (id, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.get(`/api/bookings/${id}`, config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch booking details. Please try again.'
      );
    }
  }
);

// Get user's bookings
export const getMyBookings = createAsyncThunk(
  'bookings/getMyBookings',
  async (_, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.get('/api/bookings/my-bookings', config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch your bookings. Please try again.'
      );
    }
  }
);

// Get technician's bookings
export const getTechnicianBookings = createAsyncThunk(
  'bookings/getTechnicianBookings',
  async (_, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.get('/api/bookings/technician-bookings', config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch technician bookings. Please try again.'
      );
    }
  }
);

// Create booking
export const createBooking = createAsyncThunk(
  'bookings/createBooking',
  async (bookingData, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.post('/api/bookings', bookingData, config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to create booking. Please try again.'
      );
    }
  }
);

// Update booking status
export const updateBookingStatus = createAsyncThunk(
  'bookings/updateBookingStatus',
  async ({ id, status }, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.put(`/api/bookings/${id}/status`, { status }, config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to update booking status. Please try again.'
      );
    }
  }
);

// Assign technician to booking
export const assignTechnician = createAsyncThunk(
  'bookings/assignTechnician',
  async ({ id, technicianId }, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        }
      };
      
      const response = await axios.put(`/api/bookings/${id}/assign`, { technicianId }, config);
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to assign technician. Please try again.'
      );
    }
  }
);

// Cancel booking
export const cancelBooking = createAsyncThunk(
  'bookings/cancelBooking',
  async (id, { rejectWithValue, getState }) => {
    try {
      const { token } = getState().auth;
      
      const config = {
        headers: {
          Authorization: `Bearer ${token}`
        }
      };
      
      await axios.delete(`/api/bookings/${id}`, config);
      return id;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to cancel booking. Please try again.'
      );
    }
  }
);

const bookingSlice = createSlice({
  name: 'bookings',
  initialState,
  reducers: {
    clearBookingError: (state) => {
      state.error = null;
    },
    clearBookingSuccess: (state) => {
      state.success = false;
    },
    clearBooking: (state) => {
      state.booking = null;
    }
  },
  extraReducers: (builder) => {
    builder
      // Get all bookings
      .addCase(getBookings.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getBookings.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookings = action.payload;
      })
      .addCase(getBookings.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Get booking by ID
      .addCase(getBookingById.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getBookingById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.booking = action.payload;
      })
      .addCase(getBookingById.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Get user's bookings
      .addCase(getMyBookings.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getMyBookings.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookings = action.payload;
      })
      .addCase(getMyBookings.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Get technician's bookings
      .addCase(getTechnicianBookings.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(getTechnicianBookings.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookings = action.payload;
      })
      .addCase(getTechnicianBookings.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Create booking
      .addCase(createBooking.pending, (state) => {
        state.isLoading = true;
        state.error = null;
        state.success = false;
      })
      .addCase(createBooking.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookings.push(action.payload);
        state.booking = action.payload;
        state.success = true;
      })
      .addCase(createBooking.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
        state.success = false;
      })
      
      // Update booking status
      .addCase(updateBookingStatus.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(updateBookingStatus.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookings = state.bookings.map(booking =>
          booking.id === action.payload.id ? action.payload : booking
        );
        state.booking = action.payload;
      })
      .addCase(updateBookingStatus.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Assign technician
      .addCase(assignTechnician.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(assignTechnician.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookings = state.bookings.map(booking =>
          booking.id === action.payload.id ? action.payload : booking
        );
        state.booking = action.payload;
      })
      .addCase(assignTechnician.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      })
      
      // Cancel booking
      .addCase(cancelBooking.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(cancelBooking.fulfilled, (state, action) => {
        state.isLoading = false;
        state.bookings = state.bookings.map(booking =>
          booking.id === action.payload ? { ...booking, status: 'CANCELLED' } : booking
        );
        if (state.booking && state.booking.id === action.payload) {
          state.booking = { ...state.booking, status: 'CANCELLED' };
        }
      })
      .addCase(cancelBooking.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload;
      });
  }
});

export const { clearBookingError, clearBookingSuccess, clearBooking } = bookingSlice.actions;

export default bookingSlice.reducer;
