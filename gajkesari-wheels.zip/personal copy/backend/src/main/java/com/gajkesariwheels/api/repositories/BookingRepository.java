package com.gajkesariwheels.api.repositories;

import com.gajkesariwheels.api.models.Booking;
import com.gajkesariwheels.api.models.BookingStatus;
import com.gajkesariwheels.api.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByCustomer(User customer);
    
    List<Booking> findByTechnician(User technician);
    
    List<Booking> findByStatus(BookingStatus status);
    
    List<Booking> findByScheduledDateTimeBetween(LocalDateTime start, LocalDateTime end);
    
    @Query("SELECT b FROM Booking b WHERE b.scheduledDateTime >= ?1 AND b.scheduledDateTime < ?2 AND b.status IN ('CONFIRMED', 'IN_PROGRESS')")
    List<Booking> findUpcomingBookings(LocalDateTime start, LocalDateTime end);
    
    List<Booking> findByCustomerAndStatus(User customer, BookingStatus status);
    
    List<Booking> findByTechnicianAndStatus(User technician, BookingStatus status);
}
