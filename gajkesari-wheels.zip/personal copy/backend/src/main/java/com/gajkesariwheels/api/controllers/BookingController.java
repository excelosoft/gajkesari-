package com.gajkesariwheels.api.controllers;

import com.gajkesariwheels.api.models.Booking;
import com.gajkesariwheels.api.models.BookingStatus;
import com.gajkesariwheels.api.models.User;
import com.gajkesariwheels.api.repositories.BookingRepository;
import com.gajkesariwheels.api.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/bookings")
public class BookingController {
    @Autowired
    BookingRepository bookingRepository;

    @Autowired
    UserRepository userRepository;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public ResponseEntity<List<Booking>> getAllBookings() {
        List<Booking> bookings = bookingRepository.findAll();
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER') or hasRole('TECHNICIAN') or @bookingRepository.findById(#id).orElse(new Booking()).getCustomer().getUsername() == authentication.name")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long id) {
        Optional<Booking> booking = bookingRepository.findById(id);
        if (booking.isPresent()) {
            return ResponseEntity.ok(booking.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/my-bookings")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<List<Booking>> getMyBookings() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isPresent()) {
            List<Booking> bookings = bookingRepository.findByCustomer(user.get());
            return ResponseEntity.ok(bookings);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/technician-bookings")
    @PreAuthorize("hasRole('TECHNICIAN')")
    public ResponseEntity<List<Booking>> getTechnicianBookings() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isPresent()) {
            List<Booking> bookings = bookingRepository.findByTechnician(user.get());
            return ResponseEntity.ok(bookings);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public ResponseEntity<List<Booking>> getBookingsByStatus(@PathVariable String status) {
        try {
            BookingStatus bookingStatus = BookingStatus.valueOf(status.toUpperCase());
            List<Booking> bookings = bookingRepository.findByStatus(bookingStatus);
            return ResponseEntity.ok(bookings);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Booking> createBooking(@RequestBody Booking booking) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isPresent()) {
            booking.setCustomer(user.get());
            booking.setBookingDateTime(LocalDateTime.now());
            booking.setStatus(BookingStatus.PENDING);
            
            Booking savedBooking = bookingRepository.save(booking);
            return ResponseEntity.ok(savedBooking);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER') or hasRole('TECHNICIAN')")
    public ResponseEntity<Booking> updateBookingStatus(@PathVariable Long id, @RequestBody StatusUpdateRequest statusUpdate) {
        Optional<Booking> optionalBooking = bookingRepository.findById(id);
        if (optionalBooking.isPresent()) {
            try {
                BookingStatus newStatus = BookingStatus.valueOf(statusUpdate.getStatus().toUpperCase());
                Booking booking = optionalBooking.get();
                booking.setStatus(newStatus);
                
                if (newStatus == BookingStatus.COMPLETED) {
                    booking.setCompletedDateTime(LocalDateTime.now());
                }
                
                Booking updatedBooking = bookingRepository.save(booking);
                return ResponseEntity.ok(updatedBooking);
            } catch (IllegalArgumentException e) {
                return ResponseEntity.badRequest().build();
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}/assign")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public ResponseEntity<Booking> assignTechnician(@PathVariable Long id, @RequestBody TechnicianAssignRequest assignRequest) {
        Optional<Booking> optionalBooking = bookingRepository.findById(id);
        Optional<User> optionalTechnician = userRepository.findById(assignRequest.getTechnicianId());
        
        if (optionalBooking.isPresent() && optionalTechnician.isPresent()) {
            Booking booking = optionalBooking.get();
            User technician = optionalTechnician.get();
            
            booking.setTechnician(technician);
            booking.setStatus(BookingStatus.CONFIRMED);
            
            Booking updatedBooking = bookingRepository.save(booking);
            return ResponseEntity.ok(updatedBooking);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER') or @bookingRepository.findById(#id).orElse(new Booking()).getCustomer().getUsername() == authentication.name")
    public ResponseEntity<?> cancelBooking(@PathVariable Long id) {
        Optional<Booking> optionalBooking = bookingRepository.findById(id);
        if (optionalBooking.isPresent()) {
            Booking booking = optionalBooking.get();
            booking.setStatus(BookingStatus.CANCELLED);
            bookingRepository.save(booking);
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    // Request classes
    
    public static class StatusUpdateRequest {
        private String status;

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
    
    public static class TechnicianAssignRequest {
        private Long technicianId;

        public Long getTechnicianId() {
            return technicianId;
        }

        public void setTechnicianId(Long technicianId) {
            this.technicianId = technicianId;
        }
    }
}
