package com.gajkesariwheels.api.repositories;

import com.gajkesariwheels.api.models.Service;
import com.gajkesariwheels.api.models.ServiceCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ServiceRepository extends JpaRepository<Service, Long> {
    List<Service> findByCategory(ServiceCategory category);
    
    List<Service> findByIsActiveTrue();
    
    List<Service> findByCategoryAndIsActiveTrue(ServiceCategory category);
}
