package com.gajkesariwheels.api.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "bookings")
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User customer;

    @NotNull
    private LocalDateTime bookingDateTime;

    @NotNull
    private LocalDateTime scheduledDateTime;

    @Size(max = 100)
    private String carModel;

    @Size(max = 20)
    private String carRegistration;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private BookingStatus status;

    private Boolean isDoorstepService;

    @Size(max = 255)
    private String address;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "booking_services",
               joinColumns = @JoinColumn(name = "booking_id"),
               inverseJoinColumns = @JoinColumn(name = "service_id"))
    private Set<Service> services = new HashSet<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "technician_id")
    private User technician;

    private BigDecimal totalAmount;

    @Size(max = 500)
    private String notes;

    private LocalDateTime completedDateTime;
}
