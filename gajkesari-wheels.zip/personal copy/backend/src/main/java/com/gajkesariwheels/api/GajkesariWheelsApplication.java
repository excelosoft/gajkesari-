package com.gajkesariwheels.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GajkesariWheelsApplication {

    public static void main(String[] args) {
        SpringApplication.run(GajkesariWheelsApplication.class, args);
    }
}
