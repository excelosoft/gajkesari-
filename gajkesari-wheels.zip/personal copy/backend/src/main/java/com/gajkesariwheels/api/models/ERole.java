package com.gajkesariwheels.api.models;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_TECHNICIAN,
    ROLE_MANAGER
}
