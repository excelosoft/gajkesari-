package com.gajkesariwheels.api.models;

public enum ServiceCategory {
    EXPRESS_SERVICE,
    PERIODIC_SERVICE,
    AC_SERVICE,
    CAR_SPA_CLEANING,
    DENTING_PAINTING,
    BATTERY_SERVICE,
    WINDSHIELD_SERVICE,
    CAR_DETAILING,
    TYRE_SERVICE,
    INSURANCE_CLAIMS,
    BODY_REPAIR
}
